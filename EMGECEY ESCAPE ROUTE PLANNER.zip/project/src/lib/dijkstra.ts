// ============================================================================
// Dijkstra's Shortest-Path Algorithm
// ----------------------------------------------------------------------------
// This is the heart of the Emergency Escape Route Planner. Given a weighted
// graph (nodes + edges), a start node, and a set of blocked edges/nodes, it
// finds the shortest path to every other node using the classic Dijkstra
// approach with a min-priority queue (binary heap).
//
// Algorithm overview (for viva explanation):
//   1. Assign every node a tentative distance of Infinity, except the start
//      node which gets 0.
//   2. Push the start node into a min-heap ordered by tentative distance.
//   3. Pop the node with the smallest tentative distance (the "current" node).
//   4. For each neighbour connected by an unblocked edge, calculate the
//      distance through the current node. If it's smaller than the neighbour's
//      stored tentative distance, update it and record the current node as the
//      predecessor.
//   5. Repeat until the heap is empty (all reachable nodes visited).
//   6. Reconstruct any path by walking backwards through the predecessor map.
// ============================================================================

import type { CampusEdge, CampusNode, RouteResult } from '@/types';

/** A simple binary min-heap keyed by distance — gives O(E log V) Dijkstra. */
class MinHeap {
  private items: { id: string; dist: number }[] = [];

  get size() {
    return this.items.length;
  }

  push(id: string, dist: number) {
    this.items.push({ id, dist });
    this.bubbleUp(this.items.length - 1);
  }

  pop(): { id: string; dist: number } | undefined {
    if (this.items.length === 0) return undefined;
    const top = this.items[0];
    const last = this.items.pop()!;
    if (this.items.length > 0) {
      this.items[0] = last;
      this.sinkDown(0);
    }
    return top;
  }

  private bubbleUp(i: number) {
    const item = this.items[i];
    while (i > 0) {
      const parentIdx = Math.floor((i - 1) / 2);
      const parent = this.items[parentIdx];
      if (item.dist >= parent.dist) break;
      this.items[i] = parent;
      i = parentIdx;
    }
    this.items[i] = item;
  }

  private sinkDown(i: number) {
    const length = this.items.length;
    const item = this.items[i];
    while (true) {
      const left = 2 * i + 1;
      const right = 2 * i + 2;
      let swap = -1;
      if (left < length && this.items[left].dist < item.dist) swap = left;
      if (right < length && this.items[right].dist < (swap === -1 ? item.dist : this.items[left].dist))
        swap = right;
      if (swap === -1) break;
      this.items[i] = this.items[swap];
      i = swap;
    }
    this.items[i] = item;
  }
}

interface DijkstraResult {
  /** node id -> shortest distance from start (metres) */
  distances: Record<string, number>;
  /** node id -> predecessor node id on the shortest path */
  predecessors: Record<string, string | null>;
}

/** Core Dijkstra run. Blocked edges and nodes are excluded from the graph. */
function dijkstra(
  nodes: CampusNode[],
  edges: CampusEdge[],
  startId: string,
  blockedEdgeIds: Set<string>,
  blockedNodeIds: Set<string>,
): DijkstraResult {
  const distances: Record<string, number> = {};
  const predecessors: Record<string, string | null> = {};

  // Step 1 — initialise all distances to Infinity
  for (const node of nodes) {
    distances[node.id] = Infinity;
    predecessors[node.id] = null;
  }
  if (distances[startId] === undefined) return { distances, predecessors };
  distances[startId] = 0;

  // Build an adjacency list, skipping blocked edges and blocked endpoints
  const adjacency: Record<string, { neighbour: string; distance: number; edgeId: string }[]> = {};
  for (const node of nodes) adjacency[node.id] = [];
  for (const edge of edges) {
    if (blockedEdgeIds.has(edge.id)) continue;
    if (blockedNodeIds.has(edge.source) || blockedNodeIds.has(edge.target)) continue;
    adjacency[edge.source].push({ neighbour: edge.target, distance: edge.distance, edgeId: edge.id });
    adjacency[edge.target].push({ neighbour: edge.source, distance: edge.distance, edgeId: edge.id });
  }

  // Step 2 — min-heap seeded with the start node
  const heap = new MinHeap();
  heap.push(startId, 0);
  const visited = new Set<string>();

  while (heap.size > 0) {
    // Step 3 — current node = smallest tentative distance
    const current = heap.pop()!;
    if (visited.has(current.id)) continue;
    visited.add(current.id);

    // Step 4 — relax each unvisited neighbour
    for (const { neighbour, distance } of adjacency[current.id]) {
      if (visited.has(neighbour)) continue;
      const alt = distances[current.id] + distance;
      if (alt < distances[neighbour]) {
        distances[neighbour] = alt;
        predecessors[neighbour] = current.id;
        heap.push(neighbour, alt);
      }
    }
  }

  return { distances, predecessors };
}

/** Reconstruct the path from start → target using the predecessor map. */
function reconstructPath(
  predecessors: Record<string, string | null>,
  targetId: string,
): string[] {
  const path: string[] = [];
  let current: string | null = targetId;
  while (current !== null) {
    path.unshift(current);
    current = predecessors[current];
    if (path.length > 500) break; // safety guard against cycles
  }
  return path;
}

/** Average brisk walking speed during evacuation ~1.4 m/s. */
const WALK_SPEED_MPS = 1.4;

/**
 * Find the single shortest route from `startId` to `targetId`, honouring
 * blocked edges/nodes. Returns null if no route exists.
 */
export function findShortestRoute(
  nodes: CampusNode[],
  edges: CampusEdge[],
  startId: string,
  targetId: string,
  blockedEdgeIds: Set<string>,
  blockedNodeIds: Set<string>,
): RouteResult | null {
  const { distances, predecessors } = dijkstra(
    nodes,
    edges,
    startId,
    blockedEdgeIds,
    blockedNodeIds,
  );
  if (distances[targetId] === Infinity) return null;
  const path = reconstructPath(predecessors, targetId);
  if (path.length < 2 || path[0] !== startId) return null;

  return {
    path,
    distance: distances[targetId],
    timeSeconds: Math.round(distances[targetId] / WALK_SPEED_MPS),
    directions: buildDirections(path, nodes),
  };
}

/**
 * Find the shortest route from `startId` to the nearest node among
 * `candidateTargetIds` (typically all emergency exits / gates).
 */
export function findNearestExit(
  nodes: CampusNode[],
  edges: CampusEdge[],
  startId: string,
  candidateTargetIds: string[],
  blockedEdgeIds: Set<string>,
  blockedNodeIds: Set<string>,
): { targetId: string; route: RouteResult } | null {
  const { distances, predecessors } = dijkstra(
    nodes,
    edges,
    startId,
    blockedEdgeIds,
    blockedNodeIds,
  );

  let bestTarget: string | null = null;
  let bestDist = Infinity;
  for (const targetId of candidateTargetIds) {
    if (distances[targetId] !== undefined && distances[targetId] < bestDist) {
      bestDist = distances[targetId];
      bestTarget = targetId;
    }
  }
  if (bestTarget === null) return null;

  const path = reconstructPath(predecessors, bestTarget);
  if (path.length < 2 || path[0] !== startId) return null;

  return {
    targetId: bestTarget,
    route: {
      path,
      distance: bestDist,
      timeSeconds: Math.round(bestDist / WALK_SPEED_MPS),
      directions: buildDirections(path, nodes),
    },
  };
}

/** Generate human-readable, turn-by-turn walking directions. */
function buildDirections(path: string[], nodes: CampusNode[]): string[] {
  const labelMap = new Map(nodes.map((n) => [n.id, n]));
  const directions: string[] = [];
  if (path.length === 0) return directions;
  directions.push(`Start at ${labelMap.get(path[0])?.label ?? path[0]}.`);
  for (let i = 1; i < path.length; i++) {
    const prev = labelMap.get(path[i - 1]);
    const curr = labelMap.get(path[i]);
    const prevLabel = prev?.label ?? path[i - 1];
    const currLabel = curr?.label ?? path[i];
    if (i === path.length - 1) {
      directions.push(`Exit through ${currLabel} — you have reached safety.`);
    } else if (curr?.type === 'stairs') {
      directions.push(`Take the stairs at ${currLabel}.`);
    } else if (curr?.type === 'corridor') {
      directions.push(`Continue along ${currLabel}.`);
    } else if (curr?.type === 'intersection') {
      directions.push(`At ${currLabel}, follow the highlighted path.`);
    } else {
      directions.push(`Head toward ${currLabel}.`);
    }
  }
  return directions;
}
