// ============================================================================
// Sample Campus Graph Data
// ----------------------------------------------------------------------------
// This file defines the college campus as a weighted graph of nodes and
// edges. It is intentionally hand-authored so the project is easy to
// demonstrate and explain during a viva — no database required for the core
// algorithm to work. The layout uses a 1000×640 SVG viewBox.
//
// Campus layout (rough top-down view):
//
//   ┌──────────────────────────────────────────────────────────┐
//   │  MAIN GATE (Gate-1)                       GATE-2          │
//   │      │                                     │              │
//   │   Main Corridor ── CS Dept ── Library ── Corridor-B       │
//   │      │                  │           │           │        │
//   │   Lecture Hall-1    Stairwell-1   Cafeteria   Emergency   │
//   │                                                   Exit-A  │
//   │   Lecture Hall-2    Lab-1        Admin Block              │
//   │      │                  │           │                    │
//   │   Corridor-C      Corridor-D    Corridor-E                │
//   └──────────────────────────────────────────────────────────┘
// ============================================================================

import type { CampusNode, CampusEdge, DemoScenario } from '@/types';

// ---------------------------------------------------------------------------
// NODES — classrooms, corridors, intersections, stairs, exits, gates
// ---------------------------------------------------------------------------
export const CAMPUS_NODES: CampusNode[] = [
  // Gates & exits
  { id: 'gate-1', label: 'Main Gate (Gate 1)', type: 'gate', x: 80, y: 60, description: 'Primary entrance/exit on the north-west side.' },
  { id: 'gate-2', label: 'Gate 2', type: 'gate', x: 920, y: 60, description: 'Secondary exit on the north-east side.' },
  { id: 'exit-a', label: 'Emergency Exit A', type: 'exit', x: 920, y: 580, description: 'Emergency-only exit at the south-east corner.' },
  { id: 'exit-b', label: 'Emergency Exit B', type: 'exit', x: 80, y: 580, description: 'Emergency-only exit at the south-west corner.' },

  // Main corridors
  { id: 'main-corridor', label: 'Main Corridor', type: 'corridor', x: 380, y: 60, description: 'Central spine corridor connecting the main gate to academic blocks.' },
  { id: 'corridor-b', label: 'Corridor B', type: 'corridor', x: 760, y: 200, description: 'East wing corridor near the cafeteria.' },
  { id: 'corridor-c', label: 'Corridor C', type: 'corridor', x: 200, y: 360, description: 'South-west corridor near lecture halls.' },
  { id: 'corridor-d', label: 'Corridor D', type: 'corridor', x: 480, y: 360, description: 'Central south corridor near labs.' },
  { id: 'corridor-e', label: 'Corridor E', type: 'corridor', x: 760, y: 360, description: 'South-east corridor near admin block.' },

  // Intersections
  { id: 'int-1', label: 'Intersection 1', type: 'intersection', x: 380, y: 200, description: 'Junction of main corridor and CS Department spur.' },
  { id: 'int-2', label: 'Intersection 2', type: 'intersection', x: 620, y: 200, description: 'Junction between library and Corridor B.' },
  { id: 'int-3', label: 'Intersection 3', type: 'intersection', x: 480, y: 280, description: 'Junction connecting Corridor D to the central spine.' },
  { id: 'int-4', label: 'Intersection 4', type: 'intersection', x: 200, y: 280, description: 'Junction connecting Corridor C to lecture halls.' },
  { id: 'int-5', label: 'Intersection 5', type: 'intersection', x: 760, y: 480, description: 'Junction near Emergency Exit A and Corridor E.' },

  // Academic rooms / buildings
  { id: 'cs-dept', label: 'CS Department', type: 'building', x: 380, y: 320, description: 'Computer Science Department — common demo start location.' },
  { id: 'library', label: 'Library', type: 'building', x: 620, y: 320, description: 'Central campus library.' },
  { id: 'lecture-1', label: 'Lecture Hall 1', type: 'classroom', x: 120, y: 200, description: 'Large first-year lecture hall.' },
  { id: 'lecture-2', label: 'Lecture Hall 2', type: 'classroom', x: 120, y: 440, description: 'Large second-year lecture hall.' },
  { id: 'lab-1', label: 'Lab 1', type: 'classroom', x: 480, y: 440, description: 'Computer / electronics lab.' },
  { id: 'cafeteria', label: 'Cafeteria', type: 'building', x: 760, y: 120, description: 'Campus cafeteria and dining area.' },
  { id: 'admin', label: 'Admin Block', type: 'building', x: 620, y: 480, description: 'Administrative offices.' },

  // Stairs
  { id: 'stair-1', label: 'Stairwell 1', type: 'stairs', x: 500, y: 200, description: 'Primary stairwell near the CS Department.' },
  { id: 'stair-2', label: 'Stairwell 2', type: 'stairs', x: 700, y: 360, description: 'Secondary stairwell near the admin block.' },
];

// ---------------------------------------------------------------------------
// EDGES — walkable paths with distances in metres
// ---------------------------------------------------------------------------
export const CAMPUS_EDGES: CampusEdge[] = [
  // From Main Gate
  { id: 'e-g1-main', source: 'gate-1', target: 'main-corridor', distance: 30 },
  { id: 'e-g1-l1', source: 'gate-1', target: 'lecture-1', distance: 55 },
  { id: 'e-g1-exb', source: 'gate-1', target: 'exit-b', distance: 120 },

  // From Gate 2
  { id: 'e-g2-main', source: 'gate-2', target: 'main-corridor', distance: 50 },
  { id: 'e-g2-caf', source: 'gate-2', target: 'cafeteria', distance: 40 },

  // Main corridor spine
  { id: 'e-main-int1', source: 'main-corridor', target: 'int-1', distance: 25 },
  { id: 'e-main-stair1', source: 'main-corridor', target: 'stair-1', distance: 35 },

  // Intersection 1 area
  { id: 'e-int1-cs', source: 'int-1', target: 'cs-dept', distance: 30 },
  { id: 'e-int1-stair1', source: 'int-1', target: 'stair-1', distance: 15 },
  { id: 'e-stair1-int3', source: 'stair-1', target: 'int-3', distance: 20 },
  { id: 'e-stair1-lib', source: 'stair-1', target: 'library', distance: 35 },

  // Intersection 2 / library / corridor-b
  { id: 'e-lib-int2', source: 'library', target: 'int-2', distance: 20 },
  { id: 'e-int2-cb', source: 'int-2', target: 'corridor-b', distance: 15 },
  { id: 'e-cb-caf', source: 'corridor-b', target: 'cafeteria', distance: 25 },
  { id: 'e-cb-exa', source: 'corridor-b', target: 'exit-a', distance: 90 },
  { id: 'e-int2-stair2', source: 'int-2', target: 'stair-2', distance: 45 },

  // CS Department connections
  { id: 'e-cs-int3', source: 'cs-dept', target: 'int-3', distance: 20 },
  { id: 'e-cs-lib', source: 'cs-dept', target: 'library', distance: 40 },

  // Intersection 3 / Corridor D
  { id: 'e-int3-cd', source: 'int-3', target: 'corridor-d', distance: 15 },
  { id: 'e-cd-lab1', source: 'corridor-d', target: 'lab-1', distance: 20 },
  { id: 'e-cd-int4', source: 'corridor-d', target: 'int-4', distance: 50 },
  { id: 'e-cd-ce', source: 'corridor-d', target: 'corridor-e', distance: 45 },

  // Lecture halls
  { id: 'e-l1-int4', source: 'lecture-1', target: 'int-4', distance: 30 },
  { id: 'e-int4-cc', source: 'int-4', target: 'corridor-c', distance: 15 },
  { id: 'e-cc-l2', source: 'corridor-c', target: 'lecture-2', distance: 20 },
  { id: 'e-cc-exb', source: 'corridor-c', target: 'exit-b', distance: 50 },

  // Admin block / corridor E / stair 2
  { id: 'e-ce-admin', source: 'corridor-e', target: 'admin', distance: 20 },
  { id: 'e-admin-int5', source: 'admin', target: 'int-5', distance: 15 },
  { id: 'e-int5-exa', source: 'int-5', target: 'exit-a', distance: 25 },
  { id: 'e-ce-stair2', source: 'corridor-e', target: 'stair-2', distance: 20 },
  { id: 'e-stair2-int5', source: 'stair-2', target: 'int-5', distance: 35 },

  // Lecture hall 2 to exit B
  { id: 'e-l2-exb', source: 'lecture-2', target: 'exit-b', distance: 60 },

  // Lab 1 to corridor E (back route)
  { id: 'e-lab1-ce', source: 'lab-1', target: 'corridor-e', distance: 55 },
];

// ---------------------------------------------------------------------------
// DEMO SCENARIO — Fire in the main corridor (used on Home + Emergency Mode)
// ---------------------------------------------------------------------------
export const DEMO_SCENARIO: DemoScenario = {
  startNodeId: 'cs-dept',
  emergency: 'Fire in the Main Corridor',
  description:
    'A fire has broken out in the main corridor, blocking the most direct path from the CS Department to Gate 1. The system removes that blocked edge, runs Dijkstra\u2019s algorithm, and routes you to the nearest safe exit instead.',
  blockedEdgeIds: ['e-g1-main', 'e-main-int1', 'e-main-stair1'],
  blockedNodeIds: ['main-corridor'],
};

/** All node ids that are gates or emergency exits. */
export const EXIT_NODE_IDS = CAMPUS_NODES.filter(
  (n) => n.type === 'gate' || n.type === 'exit',
).map((n) => n.id);

/** Convenience lookup map. */
export const NODE_MAP = new Map(CAMPUS_NODES.map((n) => [n.id, n]));
