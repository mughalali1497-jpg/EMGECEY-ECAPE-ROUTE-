// ============================================================================
// AppContext — shared state for the whole application
// ----------------------------------------------------------------------------
// This context holds the campus graph (nodes + edges) and the current set of
// blockages, plus the selected start location and target exit. Any page can
// read or update this state through the `useApp()` hook. Keeping everything
// in one context makes it easy to explain the data flow during a viva:
//
//   User selects location → context updates → Route Planner / Emergency
//   Mode re-run Dijkstra → map highlights the new path.
// ============================================================================

import {
  createContext,
  useContext,
  useState,
  useCallback,
  type ReactNode,
} from 'react';
import type { CampusNode, CampusEdge, Blockage, RouteResult } from '@/types';
import {
  CAMPUS_NODES,
  CAMPUS_EDGES,
  EXIT_NODE_IDS,
  NODE_MAP,
} from '@/lib/campusData';
import { findShortestRoute, findNearestExit } from '@/lib/dijkstra';

interface AppContextValue {
  // Graph data
  nodes: CampusNode[];
  edges: CampusEdge[];

  // Blockage state
  blockages: Blockage[];
  blockedEdgeIds: Set<string>;
  blockedNodeIds: Set<string>;
  addBlockage: (b: Omit<Blockage, 'id'>) => void;
  removeBlockage: (id: string) => void;
  clearBlockages: () => void;
  isNodeBlocked: (nodeId: string) => boolean;
  isEdgeBlocked: (edgeId: string) => boolean;

  // Location selection
  startNodeId: string | null;
  setStartNodeId: (id: string | null) => void;
  targetNodeId: string | null;
  setTargetNodeId: (id: string | null) => void;

  // Admin: graph editing
  addNode: (node: Omit<CampusNode, 'id'>) => void;
  removeNode: (nodeId: string) => void;
  addEdge: (edge: Omit<CampusEdge, 'id'>) => void;
  removeEdge: (edgeId: string) => void;

  // Routing helpers
  computeRouteToTarget: () => RouteResult | null;
  computeNearestExit: () => { targetId: string; route: RouteResult } | null;
  computeAlternativeRoute: () => RouteResult | null;

  // Exit list
  exitNodeIds: string[];
  nodeMap: Map<string, CampusNode>;
}

const AppContext = createContext<AppContextValue | null>(null);

let blockageCounter = 0;
let nodeCounter = 1000;
let edgeCounter = 1000;

export function AppProvider({ children }: { children: ReactNode }) {
  const [nodes, setNodes] = useState<CampusNode[]>(CAMPUS_NODES);
  const [edges, setEdges] = useState<CampusEdge[]>(CAMPUS_EDGES);
  const [blockages, setBlockages] = useState<Blockage[]>([]);
  const [startNodeId, setStartNodeId] = useState<string | null>(null);
  const [targetNodeId, setTargetNodeId] = useState<string | null>(null);

  const blockedEdgeIds = new Set(
    blockages.filter((b) => b.kind === 'edge').map((b) => b.refId),
  );
  const blockedNodeIds = new Set(
    blockages.filter((b) => b.kind === 'node').map((b) => b.refId),
  );

  const addBlockage = useCallback((b: Omit<Blockage, 'id'>) => {
    const id = `blk-${++blockageCounter}`;
    setBlockages((prev) => [...prev, { ...b, id }]);
  }, []);

  const removeBlockage = useCallback((id: string) => {
    setBlockages((prev) => prev.filter((b) => b.id !== id));
  }, []);

  const clearBlockages = useCallback(() => setBlockages([]), []);

  const isNodeBlocked = useCallback(
    (nodeId: string) => blockedNodeIds.has(nodeId),
    [blockedNodeIds],
  );
  const isEdgeBlocked = useCallback(
    (edgeId: string) => blockedEdgeIds.has(edgeId),
    [blockedEdgeIds],
  );

  const addNode = useCallback((node: Omit<CampusNode, 'id'>) => {
    const id = `node-${++nodeCounter}`;
    setNodes((prev) => [...prev, { ...node, id }]);
  }, []);

  const removeNode = useCallback((nodeId: string) => {
    setNodes((prev) => prev.filter((n) => n.id !== nodeId));
    setEdges((prev) => prev.filter((e) => e.source !== nodeId && e.target !== nodeId));
  }, []);

  const addEdge = useCallback((edge: Omit<CampusEdge, 'id'>) => {
    const id = `edge-${++edgeCounter}`;
    setEdges((prev) => [...prev, { ...edge, id }]);
  }, []);

  const removeEdge = useCallback((edgeId: string) => {
    setEdges((prev) => prev.filter((e) => e.id !== edgeId));
  }, []);

  const computeRouteToTarget = useCallback((): RouteResult | null => {
    if (!startNodeId || !targetNodeId) return null;
    return findShortestRoute(
      nodes,
      edges,
      startNodeId,
      targetNodeId,
      blockedEdgeIds,
      blockedNodeIds,
    );
  }, [startNodeId, targetNodeId, nodes, edges, blockedEdgeIds, blockedNodeIds]);

  const computeNearestExit = useCallback(() => {
    if (!startNodeId) return null;
    return findNearestExit(
      nodes,
      edges,
      startNodeId,
      EXIT_NODE_IDS.filter((id) => nodes.some((n) => n.id === id)),
      blockedEdgeIds,
      blockedNodeIds,
    );
  }, [startNodeId, nodes, edges, blockedEdgeIds, blockedNodeIds]);

  const computeAlternativeRoute = useCallback((): RouteResult | null => {
    if (!startNodeId || !targetNodeId) return null;
    // Find the shortest route, then block its edges and find the next best
    const primary = findShortestRoute(
      nodes,
      edges,
      startNodeId,
      targetNodeId,
      blockedEdgeIds,
      blockedNodeIds,
    );
    if (!primary || primary.path.length < 2) return null;

    // Build edge ids for the primary path and temporarily block them
    const primaryEdgeIds = new Set<string>();
    for (let i = 0; i < primary.path.length - 1; i++) {
      const s = primary.path[i];
      const t = primary.path[i + 1];
      for (const e of edges) {
        if ((e.source === s && e.target === t) || (e.source === t && e.target === s)) {
          primaryEdgeIds.add(e.id);
          break;
        }
      }
    }
    const altBlocked = new Set([...blockedEdgeIds, ...primaryEdgeIds]);
    return findShortestRoute(
      nodes,
      edges,
      startNodeId,
      targetNodeId,
      altBlocked,
      blockedNodeIds,
    );
  }, [startNodeId, targetNodeId, nodes, edges, blockedEdgeIds, blockedNodeIds]);

  const value: AppContextValue = {
    nodes,
    edges,
    blockages,
    blockedEdgeIds,
    blockedNodeIds,
    addBlockage,
    removeBlockage,
    clearBlockages,
    isNodeBlocked,
    isEdgeBlocked,
    startNodeId,
    setStartNodeId,
    targetNodeId,
    setTargetNodeId,
    addNode,
    removeNode,
    addEdge,
    removeEdge,
    computeRouteToTarget,
    computeNearestExit,
    computeAlternativeRoute,
    exitNodeIds: EXIT_NODE_IDS,
    nodeMap: NODE_MAP,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

/** Access the shared app state from any component. */
export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
