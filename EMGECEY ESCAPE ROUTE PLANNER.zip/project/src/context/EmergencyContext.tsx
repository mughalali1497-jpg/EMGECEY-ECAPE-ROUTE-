// ============================================================================
// EmergencyContext — shared emergency state, student status, and problem reports
// ----------------------------------------------------------------------------
// This context bridges the Supabase database with the React app. It exposes:
//   - emergencyState: the single admin-controlled row declaring whether an
//     emergency is active, what type, and a description.
//   - studentStatuses: all student check-ins during the active emergency.
//   - problemReports: all student-submitted safety problem reports.
//   - submitStudentStatus: lets a student check in as safe / in danger.
//   - updateStudentStatus: lets a student edit their check-in.
//   - submitProblemReport: lets a student file a safety problem report.
//   - updateProblemReportStatus: admin updates a report's status/notes.
//   - deleteProblemReport: admin or student removes a report.
//   - activateEmergency / deactivateEmergency: admin controls.
//   - deleteStudentStatus: admin can remove a check-in.
// ============================================================================

import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  type ReactNode,
} from 'react';
import { supabase } from '@/lib/supabase';

export interface EmergencyState {
  id: number;
  is_active: boolean;
  emergency_type: string;
  description: string;
  voice_message: string;
  activated_at: string | null;
  updated_at: string;
}

export type StudentSafetyStatus = 'safe' | 'in_danger' | 'evacuating';

export interface StudentStatus {
  id: string;
  student_name: string;
  student_id_number: string;
  location: string;
  status: StudentSafetyStatus;
  notes: string;
  emergency_id: number | null;
  created_at: string;
  updated_at: string;
}

export type ProblemPriority = 'Low' | 'Medium' | 'High' | 'Critical';
export type ReportStatus = 'pending' | 'reviewed' | 'resolved';

export interface ProblemReport {
  id: string;
  student_name: string;
  student_roll_number: string;
  student_mobile: string;
  problem_type: string;
  building_block: string;
  floor: string;
  room_area: string;
  map_node_id: string;
  description: string;
  photo_url: string;
  priority: ProblemPriority;
  status: ReportStatus;
  admin_notes: string;
  created_at: string;
  updated_at: string;
}

interface EmergencyContextValue {
  emergencyState: EmergencyState | null;
  studentStatuses: StudentStatus[];
  problemReports: ProblemReport[];
  loading: boolean;
  error: string | null;
  submitStudentStatus: (data: {
    student_name: string;
    student_id_number: string;
    location: string;
    status: StudentSafetyStatus;
    notes: string;
  }) => Promise<{ success: boolean; error: string | null }>;
  updateStudentStatus: (id: string, data: {
    status?: StudentSafetyStatus;
    location?: string;
    notes?: string;
  }) => Promise<{ success: boolean; error: string | null }>;
  submitProblemReport: (data: {
    student_name: string;
    student_roll_number: string;
    student_mobile: string;
    problem_type: string;
    building_block: string;
    floor: string;
    room_area: string;
    map_node_id: string;
    description: string;
    photo_url: string;
    priority: ProblemPriority;
  }) => Promise<{ success: boolean; error: string | null }>;
  updateProblemReportStatus: (id: string, status: ReportStatus, adminNotes: string) => Promise<{ success: boolean; error: string | null }>;
  deleteProblemReport: (id: string) => Promise<void>;
  activateEmergency: (type: string, description: string, voiceMessage?: string) => Promise<void>;
  deactivateEmergency: () => Promise<void>;
  deleteStudentStatus: (id: string) => Promise<void>;
  refresh: () => Promise<void>;
}

const EmergencyContext = createContext<EmergencyContextValue | null>(null);

export function EmergencyProvider({ children }: { children: ReactNode }) {
  const [emergencyState, setEmergencyState] = useState<EmergencyState | null>(null);
  const [studentStatuses, setStudentStatuses] = useState<StudentStatus[]>([]);
  const [problemReports, setProblemReports] = useState<ProblemReport[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchEmergencyState = useCallback(async () => {
    const { data, error } = await supabase
      .from('emergency_state')
      .select('*')
      .eq('id', 1)
      .maybeSingle();
    if (error) {
      setError(error.message);
      return;
    }
    setEmergencyState(data as EmergencyState | null);
  }, []);

  const fetchStudentStatuses = useCallback(async () => {
    const { data, error } = await supabase
      .from('student_status')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) {
      setError(error.message);
      return;
    }
    setStudentStatuses((data as StudentStatus[]) ?? []);
  }, []);

  const fetchProblemReports = useCallback(async () => {
    const { data, error } = await supabase
      .from('problem_reports')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) {
      setError(error.message);
      return;
    }
    setProblemReports((data as ProblemReport[]) ?? []);
  }, []);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError(null);
    await Promise.all([fetchEmergencyState(), fetchStudentStatuses(), fetchProblemReports()]);
    setLoading(false);
  }, [fetchEmergencyState, fetchStudentStatuses, fetchProblemReports]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  // Realtime subscription for all table changes
  useEffect(() => {
    const channel = supabase
      .channel('emergency_state_changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'emergency_state' },
        () => fetchEmergencyState(),
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'student_status' },
        () => fetchStudentStatuses(),
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'problem_reports' },
        () => fetchProblemReports(),
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchEmergencyState, fetchStudentStatuses, fetchProblemReports]);

  const submitStudentStatus = useCallback(
    async (data: {
      student_name: string;
      student_id_number: string;
      location: string;
      status: StudentSafetyStatus;
      notes: string;
    }) => {
      const { data: inserted, error: insertError } = await supabase
        .from('student_status')
        .insert({
          student_name: data.student_name,
          student_id_number: data.student_id_number,
          location: data.location,
          status: data.status,
          notes: data.notes,
          emergency_id: 1,
        })
        .select()
        .maybeSingle();

      if (insertError) {
        return { success: false, error: insertError.message };
      }

      setStudentStatuses((prev) => [inserted as StudentStatus, ...prev]);
      return { success: true, error: null };
    },
    [],
  );

  const updateStudentStatus = useCallback(
    async (
      id: string,
      data: { status?: StudentSafetyStatus; location?: string; notes?: string },
    ) => {
      const { data: updated, error: updateError } = await supabase
        .from('student_status')
        .update(data)
        .eq('id', id)
        .select()
        .maybeSingle();

      if (updateError) {
        return { success: false, error: updateError.message };
      }

      setStudentStatuses((prev) =>
        prev.map((s) => (s.id === id ? (updated as StudentStatus) : s)),
      );
      return { success: true, error: null };
    },
    [],
  );

  const submitProblemReport = useCallback(
    async (data: {
      student_name: string;
      student_roll_number: string;
      student_mobile: string;
      problem_type: string;
      building_block: string;
      floor: string;
      room_area: string;
      map_node_id: string;
      description: string;
      photo_url: string;
      priority: ProblemPriority;
    }) => {
      const { data: inserted, error: insertError } = await supabase
        .from('problem_reports')
        .insert({
          student_name: data.student_name,
          student_roll_number: data.student_roll_number,
          student_mobile: data.student_mobile,
          problem_type: data.problem_type,
          building_block: data.building_block,
          floor: data.floor,
          room_area: data.room_area,
          map_node_id: data.map_node_id,
          description: data.description,
          photo_url: data.photo_url,
          priority: data.priority,
          status: 'pending',
        })
        .select()
        .maybeSingle();

      if (insertError) {
        return { success: false, error: insertError.message };
      }

      setProblemReports((prev) => [inserted as ProblemReport, ...prev]);
      return { success: true, error: null };
    },
    [],
  );

  const updateProblemReportStatus = useCallback(
    async (id: string, status: ReportStatus, adminNotes: string) => {
      const { data: updated, error: updateError } = await supabase
        .from('problem_reports')
        .update({ status, admin_notes: adminNotes })
        .eq('id', id)
        .select()
        .maybeSingle();

      if (updateError) {
        return { success: false, error: updateError.message };
      }

      setProblemReports((prev) =>
        prev.map((r) => (r.id === id ? (updated as ProblemReport) : r)),
      );
      return { success: true, error: null };
    },
    [],
  );

  const deleteProblemReport = useCallback(async (id: string) => {
    const { error: deleteError } = await supabase
      .from('problem_reports')
      .delete()
      .eq('id', id);
    if (deleteError) throw deleteError;
    setProblemReports((prev) => prev.filter((r) => r.id !== id));
  }, []);

  const activateEmergency = useCallback(async (type: string, description: string, voiceMessage?: string) => {
    const { error: upsertError } = await supabase
      .from('emergency_state')
      .update({
        is_active: true,
        emergency_type: type,
        description,
        voice_message: voiceMessage ?? '',
        activated_at: new Date().toISOString(),
      })
      .eq('id', 1);
    if (upsertError) throw upsertError;
    await fetchEmergencyState();
  }, [fetchEmergencyState]);

  const deactivateEmergency = useCallback(async () => {
    const { error: updateError } = await supabase
      .from('emergency_state')
      .update({
        is_active: false,
        emergency_type: '',
        description: '',
        voice_message: '',
        activated_at: null,
      })
      .eq('id', 1);
    if (updateError) throw updateError;
    await fetchEmergencyState();
  }, [fetchEmergencyState]);

  const deleteStudentStatus = useCallback(async (id: string) => {
    const { error: deleteError } = await supabase
      .from('student_status')
      .delete()
      .eq('id', id);
    if (deleteError) throw deleteError;
    setStudentStatuses((prev) => prev.filter((s) => s.id !== id));
  }, []);

  const value: EmergencyContextValue = {
    emergencyState,
    studentStatuses,
    problemReports,
    loading,
    error,
    submitStudentStatus,
    updateStudentStatus,
    submitProblemReport,
    updateProblemReportStatus,
    deleteProblemReport,
    activateEmergency,
    deactivateEmergency,
    deleteStudentStatus,
    refresh,
  };

  return <EmergencyContext.Provider value={value}>{children}</EmergencyContext.Provider>;
}

export function useEmergency() {
  const ctx = useContext(EmergencyContext);
  if (!ctx) throw new Error('useEmergency must be used within EmergencyProvider');
  return ctx;
}
