import {
  createContext,
  useContext,
  useState,
  useEffect,
  useRef,
  useCallback,
  type ReactNode,
} from 'react';
import { useEmergency } from '@/context/EmergencyContext';

interface VoiceContextValue {
  voicePlaying: boolean;
  startVoice: () => void;
  stopVoice: () => void;
}

const VoiceContext = createContext<VoiceContextValue | null>(null);

export function VoiceProvider({ children }: { children: ReactNode }) {
  const { emergencyState } = useEmergency();
  const [voicePlaying, setVoicePlaying] = useState(false);
  const voiceLoopRef = useRef(false);
  const voiceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const getAnnouncementText = useCallback(() => {
    if (!emergencyState?.is_active) return '';
    const type = emergencyState.emergency_type || 'Emergency';
    const desc = emergencyState.description || '';
    const predefined = `Attention. This is an emergency alert. ${type} emergency has been declared on campus. ${desc} Please evacuate immediately using the nearest exit. Do not use elevators. Stay calm and follow the evacuation routes on the campus map.`;
    const custom = emergencyState.voice_message?.trim();
    return custom ? `${predefined} ${custom}` : predefined;
  }, [emergencyState]);

  const speakAnnouncement = useCallback(() => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    const text = getAnnouncementText();
    if (!text) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.9;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;
    utterance.onend = () => {
      if (voiceLoopRef.current && emergencyState?.is_active) {
        voiceTimerRef.current = setTimeout(() => speakAnnouncement(), 2000);
      } else {
        setVoicePlaying(false);
        voiceLoopRef.current = false;
      }
    };
    window.speechSynthesis.speak(utterance);
  }, [getAnnouncementText, emergencyState]);

  const startVoice = useCallback(() => {
    if (!emergencyState?.is_active) return;
    voiceLoopRef.current = true;
    setVoicePlaying(true);
    speakAnnouncement();
  }, [emergencyState, speakAnnouncement]);

  const stopVoice = useCallback(() => {
    voiceLoopRef.current = false;
    setVoicePlaying(false);
    if (voiceTimerRef.current) {
      clearTimeout(voiceTimerRef.current);
      voiceTimerRef.current = null;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }, []);

  // Auto-play when emergency is first activated; auto-stop when deactivated
  const prevActiveRef = useRef(false);
  useEffect(() => {
    const isActive = emergencyState?.is_active ?? false;
    if (isActive && !prevActiveRef.current) {
      startVoice();
    }
    if (!isActive && prevActiveRef.current) {
      stopVoice();
    }
    prevActiveRef.current = isActive;
  }, [emergencyState?.is_active, startVoice, stopVoice]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      voiceLoopRef.current = false;
      if (voiceTimerRef.current) clearTimeout(voiceTimerRef.current);
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  return (
    <VoiceContext.Provider value={{ voicePlaying, startVoice, stopVoice }}>
      {children}
    </VoiceContext.Provider>
  );
}

export function useVoice() {
  const ctx = useContext(VoiceContext);
  if (!ctx) throw new Error('useVoice must be used within VoiceProvider');
  return ctx;
}
