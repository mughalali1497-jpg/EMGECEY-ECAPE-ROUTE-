// ============================================================================
// Core Type Definitions for the Emergency Escape Route Planner
// ----------------------------------------------------------------------------
// These types describe the campus graph (nodes + edges) that Dijkstra's
// algorithm operates on, plus the blocking/hazard state that affects routing.
// ============================================================================

/** Category of a campus node — controls icon + colour on the map. */
export type NodeType =
  | 'classroom'
  | 'corridor'
  | 'intersection'
  | 'stairs'
  | 'building'
  | 'exit'
  | 'gate'
  | 'entrance';

/** A single point of interest / waypoint on the campus graph. */
export interface CampusNode {
  id: string;
  label: string;
  type: NodeType;
  /** SVG pixel coordinates on the map canvas (1000×640 viewBox). */
  x: number;
  y: number;
  /** Short human-readable description shown in tooltips / step lists. */
  description?: string;
}

/** A walkable connection between two nodes with a distance weight (metres). */
export interface CampusEdge {
  id: string;
  source: string;
  target: string;
  /** Real-world distance in metres — used as the edge weight for Dijkstra. */
  distance: number;
}

/** A hazard / blockage flagged on a node or edge by an admin or user. */
export interface Blockage {
  id: string;
  /** "node" blocks a location, "edge" blocks a path between two locations. */
  kind: 'node' | 'edge';
  /** Node id (kind=node) or edge id (kind=edge) being blocked. */
  refId: string;
  reason: string;
}

/** A computed path from a start node to a destination, with stats. */
export interface RouteResult {
  /** Ordered list of node ids forming the path. */
  path: string[];
  /** Total distance in metres. */
  distance: number;
  /** Estimated walking time in seconds (at 1.4 m/s brisk walk). */
  timeSeconds: number;
  /** Human-readable turn-by-turn directions. */
  directions: string[];
}

/** Pre-baked demo scenario used on the Home page and Emergency Mode. */
export interface DemoScenario {
  startNodeId: string;
  blockedEdgeIds: string[];
  blockedNodeIds: string[];
  emergency: string;
  description: string;
}
