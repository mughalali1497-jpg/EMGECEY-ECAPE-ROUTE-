// ============================================================================
// CampusMap — Interactive SVG campus map
// ----------------------------------------------------------------------------
// Renders the campus graph as an interactive SVG. Nodes are drawn as circles
// with icons; edges are drawn as lines. The current route is highlighted in
// green, blocked edges/nodes in red. Clicking a node calls onSelectNode so
// the parent page can use it as a start/target selection.
// ============================================================================

import { useMemo } from 'react';
import {
  DoorOpen,
  Fence,
  Building2,
  DoorClosed,
  Columns3,
  Cross,
  Split,
  LogIn,
  HelpCircle,
} from 'lucide-react';
import type { CampusNode, NodeType } from '@/types';
import { useApp } from '@/context/AppContext';

interface CampusMapProps {
  /** Set of node ids that make up the currently highlighted route. */
  routePath?: Set<string>;
  /** Edges on the route, keyed as "source|target" (sorted). */
  routeEdgeKeys?: Set<string>;
  /** Called when the user clicks a node. */
  onSelectNode?: (nodeId: string) => void;
  /** Which selection role clicks should fill: "start", "target", or none. */
  selectionMode?: 'start' | 'target' | 'block' | null;
  /** Compact height (used in emergency mode). */
  compact?: boolean;
}

const NODE_COLORS: Record<NodeType, string> = {
  classroom: '#0ea5e9',
  corridor: '#64748b',
  intersection: '#94a3b8',
  stairs: '#f59e0b',
  building: '#0284c7',
  exit: '#22c55e',
  gate: '#16a34a',
  entrance: '#0891b2',
};

function NodeIcon({ type, size }: { type: NodeType; size: number }) {
  const props = { size, className: 'text-white' };
  switch (type) {
    case 'exit':
    case 'entrance':
      return <DoorOpen {...props} />;
    case 'gate':
      return <Fence {...props} />;
    case 'building':
      return <Building2 {...props} />;
    case 'classroom':
      return <DoorClosed {...props} />;
    case 'stairs':
      return <Columns3 {...props} />;
    case 'corridor':
      return <LogIn {...props} />;
    case 'intersection':
      return <Split {...props} />;
    default:
      return <HelpCircle {...props} />;
  }
}

function edgeKey(s: string, t: string) {
  return [s, t].sort().join('|');
}

export default function CampusMap({
  routePath,
  routeEdgeKeys,
  onSelectNode,
  selectionMode,
  compact,
}: CampusMapProps) {
  const { nodes, edges, startNodeId, targetNodeId, isNodeBlocked, isEdgeBlocked } =
    useApp();

  const nodeMap = useMemo(() => new Map(nodes.map((n) => [n.id, n])), [nodes]);

  return (
    <div
      className={`w-full overflow-hidden rounded-xl border border-slate-700 bg-slate-900 ${
        compact ? '' : 'shadow-lg'
      }`}
    >
      <svg
        viewBox="0 0 1000 640"
        className="w-full h-auto"
        style={{ display: 'block' }}
      >
        {/* Grid background */}
        <defs>
          <pattern
            id="grid"
            width="40"
            height="40"
            patternUnits="userSpaceOnUse"
          >
            <path
              d="M 40 0 L 0 0 0 40"
              fill="none"
              stroke="#1e293b"
              strokeWidth="1"
            />
          </pattern>
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
        <rect width="1000" height="640" fill="url(#grid)" />

        {/* Campus boundary */}
        <rect
          x="20"
          y="20"
          width="960"
          height="600"
          fill="none"
          stroke="#334155"
          strokeWidth="2"
          rx="12"
          strokeDasharray="8 4"
        />
        <text x="500" y="45" textAnchor="middle" fill="#475569" fontSize="14" fontWeight="600">
          COLLEGE CAMPUS — EMERGENCY EVACUATION MAP
        </text>

        {/* Edges */}
        {edges.map((edge) => {
          const s = nodeMap.get(edge.source);
          const t = nodeMap.get(edge.target);
          if (!s || !t) return null;
          const blocked = isEdgeBlocked(edge.id);
          const onRoute = routeEdgeKeys?.has(edgeKey(edge.source, edge.target));
          return (
            <line
              key={edge.id}
              x1={s.x}
              y1={s.y}
              x2={t.x}
              y2={t.y}
              stroke={blocked ? '#ef4444' : onRoute ? '#22c55e' : '#475569'}
              strokeWidth={onRoute ? 5 : blocked ? 4 : 2.5}
              strokeDasharray={blocked ? '10 6' : undefined}
              strokeLinecap="round"
              opacity={onRoute ? 1 : blocked ? 0.8 : 0.5}
              filter={onRoute ? 'url(#glow)' : undefined}
            />
          );
        })}

        {/* Nodes */}
        {nodes.map((node) => {
          const blocked = isNodeBlocked(node.id);
          const isStart = startNodeId === node.id;
          const isTarget = targetNodeId === node.id;
          const onRoute = routePath?.has(node.id);
          const fill = blocked ? '#ef4444' : NODE_COLORS[node.type];
          const radius = isStart || isTarget ? 22 : onRoute ? 18 : 15;

          return (
            <g
              key={node.id}
              onClick={() => onSelectNode?.(node.id)}
              className={onSelectNode ? 'cursor-pointer' : ''}
              style={{ transition: 'all 0.2s' }}
            >
              {/* Pulse ring for start / target */}
              {isStart && (
                <circle cx={node.x} cy={node.y} r={28} fill="none" stroke="#3b82f6" strokeWidth="2" opacity="0.5">
                  <animate attributeName="r" values="22;32;22" dur="2s" repeatCount="indefinite" />
                  <animate attributeName="opacity" values="0.6;0.1;0.6" dur="2s" repeatCount="indefinite" />
                </circle>
              )}
              {isTarget && (
                <circle cx={node.x} cy={node.y} r={28} fill="none" stroke="#a855f7" strokeWidth="2" opacity="0.5">
                  <animate attributeName="r" values="22;32;22" dur="2s" repeatCount="indefinite" />
                  <animate attributeName="opacity" values="0.6;0.1;0.6" dur="2s" repeatCount="indefinite" />
                </circle>
              )}

              <circle
                cx={node.x}
                cy={node.y}
                r={radius}
                fill={fill}
                stroke={onRoute ? '#86efac' : isStart ? '#3b82f6' : isTarget ? '#a855f7' : '#1e293b'}
                strokeWidth={onRoute ? 3 : 2}
                filter={onRoute || isStart || isTarget ? 'url(#glow)' : undefined}
              />

              {/* Icon overlay */}
              <foreignObject
                x={node.x - 10}
                y={node.y - 10}
                width="20"
                height="20"
                style={{ pointerEvents: 'none' }}
              >
                <div className="w-full h-full flex items-center justify-center">
                  <NodeIcon type={node.type} size={14} />
                </div>
              </foreignObject>

              {/* Label */}
              <text
                x={node.x}
                y={node.y + radius + 14}
                textAnchor="middle"
                fill="#cbd5e1"
                fontSize="10"
                fontWeight="600"
                style={{ pointerEvents: 'none', textShadow: '0 1px 3px #0f172a' }}
              >
                {node.label.length > 22 ? node.label.slice(0, 20) + '…' : node.label}
              </text>

              {/* Start / target badges */}
              {isStart && (
                <g>
                  <rect x={node.x - 18} y={node.y - radius - 20} width="36" height="14" rx="3" fill="#3b82f6" />
                  <text x={node.x} y={node.y - radius - 10} textAnchor="middle" fill="white" fontSize="9" fontWeight="700">
                    START
                  </text>
                </g>
              )}
              {isTarget && (
                <g>
                  <rect x={node.x - 20} y={node.y - radius - 20} width="40" height="14" rx="3" fill="#a855f7" />
                  <text x={node.x} y={node.y - radius - 10} textAnchor="middle" fill="white" fontSize="9" fontWeight="700">
                    EXIT
                  </text>
                </g>
              )}
              {blocked && (
                <g>
                  <circle cx={node.x + 12} cy={node.y - 12} r="8" fill="#dc2626" stroke="white" strokeWidth="1.5" />
                  <text x={node.x + 12} y={node.y - 9} textAnchor="middle" fill="white" fontSize="10" fontWeight="700">
                    !
                  </text>
                </g>
              )}
            </g>
          );
        })}
      </svg>

      {/* Legend */}
      {!compact && (
        <div className="flex flex-wrap items-center gap-4 border-t border-slate-700 bg-slate-800/50 px-4 py-3 text-xs text-slate-300">
          <span className="flex items-center gap-1.5">
            <span className="inline-block w-3 h-3 rounded-full bg-sky-500" /> Classroom
          </span>
          <span className="flex items-center gap-1.5">
            <span className="inline-block w-3 h-3 rounded-full bg-slate-500" /> Corridor
          </span>
          <span className="flex items-center gap-1.5">
            <span className="inline-block w-3 h-3 rounded-full bg-amber-500" /> Stairs
          </span>
          <span className="flex items-center gap-1.5">
            <span className="inline-block w-3 h-3 rounded-full bg-green-600" /> Gate / Exit
          </span>
          <span className="flex items-center gap-1.5">
            <span className="inline-block w-4 h-1 bg-green-500 rounded" /> Escape Route
          </span>
          <span className="flex items-center gap-1.5">
            <span className="inline-block w-4 h-1 bg-red-500 rounded" style={{ borderTop: '2px dashed #ef4444' }} /> Blocked
          </span>
        </div>
      )}
    </div>
  );
}
