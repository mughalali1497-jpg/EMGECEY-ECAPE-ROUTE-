// ============================================================================
// GuidanceDrop — Emergency guidance message dropdown
// ----------------------------------------------------------------------------
// A dropdown panel triggered from the header that provides real-time safety
// guidance: current hazard alerts, evacuation tips, and emergency contact
// numbers. Accessible from any page so help is always one click away.
// ============================================================================

import { useState, useRef, useEffect } from 'react';
import {
  Bell,
  X,
  AlertTriangle,
  Lightbulb,
  Phone,
  ShieldCheck,
  Ban,
  Info,
} from 'lucide-react';
import { useApp } from '@/context/AppContext';

const EMERGENCY_CONTACTS = [
  { label: 'Fire Brigade', number: '101' },
  { label: 'Ambulance', number: '102' },
  { label: 'Campus Security', number: '080-XXXX-XXXX' },
  { label: 'Emergency Helpline', number: '112' },
];

const SAFETY_TIPS = [
  'Stay calm and walk quickly — do not run or panic.',
  'Follow the green highlighted path on the campus map.',
  'Avoid areas marked with red hazard indicators.',
  'Do not use elevators during an evacuation — use stairs only.',
  'Keep low if there is smoke; cover your nose and mouth.',
  'Help others who need assistance if it is safe to do so.',
  'Once outside, move well away from the building and assemble at the muster point.',
  'Do not re-enter the building until cleared by emergency services.',
];

export default function GuidanceDrop() {
  const { blockages, startNodeId, nodeMap, computeNearestExit } = useApp();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    if (open) document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  const nearest = computeNearestExit();
  const unreadAlerts = blockages.length;
  const hasActiveRoute = !!nearest && !!startNodeId;

  return (
    <div className="relative" ref={ref}>
      {/* Bell trigger */}
      <button
        onClick={() => setOpen((v) => !v)}
        className="relative flex items-center justify-center w-9 h-9 rounded-lg bg-slate-800 border border-slate-700 text-slate-300 hover:text-white hover:border-slate-600 transition-colors"
        aria-label="Emergency guidance"
      >
        <Bell className="w-4.5 h-4.5" />
        {unreadAlerts > 0 && (
          <span className="absolute -top-1 -right-1 flex items-center justify-center min-w-[18px] h-[18px] px-1 rounded-full bg-red-500 text-white text-[10px] font-bold animate-pulse">
            {unreadAlerts}
          </span>
        )}
      </button>

      {/* Dropdown panel */}
      {open && (
        <div className="absolute right-0 top-12 z-50 w-[340px] max-w-[calc(100vw-2rem)] rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl shadow-black/50 overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between bg-gradient-to-r from-red-600/20 to-orange-600/10 border-b border-slate-700 px-4 py-3">
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4 text-red-400" />
              <span className="text-sm font-bold text-white">Emergency Guidance</span>
            </div>
            <button
              onClick={() => setOpen(false)}
              className="text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Scrollable body */}
          <div className="max-h-[420px] overflow-y-auto">
            {/* Active alerts */}
            <div className="p-4 border-b border-slate-800">
              <h4 className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-wide mb-3">
                <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
                Active Alerts
              </h4>
              {blockages.length === 0 ? (
                <div className="flex items-center gap-2 text-sm text-slate-500">
                  <ShieldCheck className="w-4 h-4 text-green-400" />
                  No active hazards. All paths are clear.
                </div>
              ) : (
                <div className="space-y-2">
                  {blockages.map((b) => {
                    const label =
                      b.kind === 'node'
                        ? nodeMap.get(b.refId)?.label ?? b.refId
                        : (() => {
                            const words = b.refId.split('-');
                            return `Path near ${words[words.length - 1]}`;
                          })();
                    return (
                      <div
                        key={b.id}
                        className="flex items-start gap-2 rounded-lg bg-red-500/10 border border-red-500/20 px-3 py-2"
                      >
                        <Ban className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-red-200">{label}</p>
                          <p className="text-[11px] text-slate-500">{b.reason}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Current route status */}
            <div className="p-4 border-b border-slate-800">
              <h4 className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-wide mb-3">
                <Info className="w-3.5 h-3.5 text-sky-400" />
                Route Status
              </h4>
              {!startNodeId ? (
                <p className="text-sm text-slate-500">
                  Select your location to receive evacuation guidance.
                </p>
              ) : !hasActiveRoute ? (
                <p className="text-sm text-red-300">
                  No safe exit found from {nodeMap.get(startNodeId)?.label}. Seek shelter immediately.
                </p>
              ) : (
                <div className="rounded-lg bg-green-500/10 border border-green-500/20 px-3 py-2.5">
                  <p className="text-sm text-green-200">
                    Nearest exit: <span className="font-bold">{nodeMap.get(nearest!.targetId)?.label}</span>
                  </p>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {nearest!.route.distance}m · ~{Math.round(nearest!.route.timeSeconds)}s to safety
                  </p>
                </div>
              )}
            </div>

            {/* Safety tips */}
            <div className="p-4 border-b border-slate-800">
              <h4 className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-wide mb-3">
                <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
                Safety Tips
              </h4>
              <ul className="space-y-1.5">
                {SAFETY_TIPS.map((tip, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs text-slate-300 leading-relaxed">
                    <span className="text-amber-400 shrink-0 mt-0.5">•</span>
                    {tip}
                  </li>
                ))}
              </ul>
            </div>

            {/* Emergency contacts */}
            <div className="p-4">
              <h4 className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-wide mb-3">
                <Phone className="w-3.5 h-3.5 text-red-400" />
                Emergency Contacts
              </h4>
              <div className="grid grid-cols-2 gap-2">
                {EMERGENCY_CONTACTS.map((c) => (
                  <a
                    key={c.label}
                    href={`tel:${c.number}`}
                    className="flex flex-col rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 hover:border-red-500/40 transition-colors"
                  >
                    <span className="text-[11px] text-slate-500">{c.label}</span>
                    <span className="text-sm font-bold text-white">{c.number}</span>
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="bg-slate-800/50 border-t border-slate-700 px-4 py-2.5 text-center">
            <p className="text-[10px] text-slate-500">
              Academic prototype — not a certified safety system
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
