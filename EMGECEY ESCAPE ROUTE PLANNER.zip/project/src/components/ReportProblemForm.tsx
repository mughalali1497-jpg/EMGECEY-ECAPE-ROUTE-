// ============================================================================
// ReportProblemForm — Student safety problem report form
// ----------------------------------------------------------------------------
// Lets students report campus safety issues with:
//   - Problem type, location (building/floor/room + map node picker)
//   - Description, photo upload, priority
//   - Student identity (name, roll number, mobile)
// ============================================================================

import { useState, useRef } from 'react';
import {
  FileText,
  Upload,
  X,
  Image as ImageIcon,
  MapPin,
  Send,
  Building2,
  Layers,
  DoorClosed,
  Phone,
  User,
  Hash,
} from 'lucide-react';
import { useEmergency, type ProblemPriority } from '@/context/EmergencyContext';
import { useApp } from '@/context/AppContext';
import { supabase } from '@/lib/supabase';

const PROBLEM_TYPES = [
  'Blocked Emergency Exit',
  'Blocked Escape Route',
  'Fire/Smoke',
  'Damaged Fire Extinguisher',
  'Emergency Light Not Working',
  'Unsafe Area',
  'Other',
];

const PRIORITIES: { value: ProblemPriority; color: string; bg: string; border: string }[] = [
  { value: 'Low', color: 'text-green-300', bg: 'bg-green-500/10', border: 'border-green-500/30' },
  { value: 'Medium', color: 'text-sky-300', bg: 'bg-sky-500/10', border: 'border-sky-500/30' },
  { value: 'High', color: 'text-amber-300', bg: 'bg-amber-500/10', border: 'border-amber-500/30' },
  { value: 'Critical', color: 'text-red-300', bg: 'bg-red-500/10', border: 'border-red-500/30' },
];

interface ReportProblemFormProps {
  onSubmitted?: () => void;
}

export default function ReportProblemForm({ onSubmitted }: ReportProblemFormProps) {
  const { submitProblemReport } = useEmergency();
  const { nodes } = useApp();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [reporterName, setReporterName] = useState('');
  const [rollNumber, setRollNumber] = useState('');
  const [mobile, setMobile] = useState('');
  const [problemType, setProblemType] = useState(PROBLEM_TYPES[0]);
  const [buildingBlock, setBuildingBlock] = useState('');
  const [floor, setFloor] = useState('');
  const [roomArea, setRoomArea] = useState('');
  const [mapNodeId, setMapNodeId] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<ProblemPriority>('Medium');
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      setMsg({ ok: false, text: 'Photo must be under 5 MB.' });
      return;
    }
    setPhotoFile(file);
    setPhotoPreview(URL.createObjectURL(file));
    setMsg(null);
  };

  const clearPhoto = () => {
    setPhotoFile(null);
    setPhotoPreview(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const uploadPhoto = async (): Promise<string> => {
    if (!photoFile) return '';
    const ext = photoFile.name.split('.').pop() ?? 'jpg';
    const fileName = `report-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
    setUploading(true);
    const { error: uploadError } = await supabase.storage
      .from('report-photos')
      .upload(fileName, photoFile);
    setUploading(false);
    if (uploadError) throw new Error(uploadError.message);
    const { data: urlData } = supabase.storage.from('report-photos').getPublicUrl(fileName);
    return urlData.publicUrl;
  };

  const handleSubmit = async () => {
    if (!reporterName.trim()) {
      setMsg({ ok: false, text: 'Please enter your name.' });
      return;
    }
    if (!problemType) {
      setMsg({ ok: false, text: 'Please select a problem type.' });
      return;
    }
    setSubmitting(true);
    setMsg(null);
    try {
      const photoUrl = await uploadPhoto();
      const result = await submitProblemReport({
        student_name: reporterName.trim(),
        student_roll_number: rollNumber.trim(),
        student_mobile: mobile.trim(),
        problem_type: problemType,
        building_block: buildingBlock.trim(),
        floor: floor.trim(),
        room_area: roomArea.trim(),
        map_node_id: mapNodeId,
        description: description.trim(),
        photo_url: photoUrl,
        priority,
      });
      setSubmitting(false);
      if (result.success) {
        setMsg({ ok: true, text: 'Your report has been submitted. The admin has been notified.' });
        setReporterName('');
        setRollNumber('');
        setMobile('');
        setBuildingBlock('');
        setFloor('');
        setRoomArea('');
        setMapNodeId('');
        setDescription('');
        setPriority('Medium');
        setProblemType(PROBLEM_TYPES[0]);
        clearPhoto();
        onSubmitted?.();
      } else {
        setMsg({ ok: false, text: result.error ?? 'Failed to submit report.' });
      }
    } catch (e) {
      setSubmitting(false);
      setMsg({ ok: false, text: (e as Error).message ?? 'Failed to upload photo.' });
    }
  };

  return (
    <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-5">
      <h2 className="flex items-center gap-2 text-sm font-bold text-white mb-1">
        <FileText className="w-4 h-4 text-amber-400" />
        Report a Safety Problem
      </h2>
      <p className="text-xs text-slate-500 mb-4">
        Report blocked exits, fire hazards, damaged equipment, or any unsafe condition on campus.
      </p>

      <div className="space-y-4">
        {/* Student identity */}
        <div className="rounded-lg bg-slate-900/40 border border-slate-700/50 p-3">
          <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wide mb-2.5">Your Details</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs text-slate-500 mb-1 flex items-center gap-1">
                <User className="w-3 h-3" /> Name *
              </label>
              <input
                type="text"
                value={reporterName}
                onChange={(e) => setReporterName(e.target.value)}
                placeholder="Full name"
                className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-xs text-slate-500 mb-1 flex items-center gap-1">
                <Hash className="w-3 h-3" /> Roll Number
              </label>
              <input
                type="text"
                value={rollNumber}
                onChange={(e) => setRollNumber(e.target.value)}
                placeholder="e.g. CS21B001"
                className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-xs text-slate-500 mb-1 flex items-center gap-1">
                <Phone className="w-3 h-3" /> Mobile Number
              </label>
              <input
                type="text"
                value={mobile}
                onChange={(e) => setMobile(e.target.value)}
                placeholder="e.g. 9876543210"
                className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Problem type */}
        <div>
          <label className="text-xs text-slate-500 mb-1.5 block">Problem Type *</label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {PROBLEM_TYPES.map((type) => {
              const active = problemType === type;
              return (
                <button
                  key={type}
                  onClick={() => setProblemType(type)}
                  className={`rounded-lg border px-3 py-2 text-xs font-semibold text-left transition-all ${
                    active
                      ? 'border-amber-500/50 bg-amber-500/10 text-amber-300'
                      : 'border-slate-700 text-slate-400 hover:border-slate-600'
                  }`}
                >
                  {type}
                </button>
              );
            })}
          </div>
        </div>

        {/* Location */}
        <div className="rounded-lg bg-slate-900/40 border border-slate-700/50 p-3">
          <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wide mb-2.5">Location</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs text-slate-500 mb-1 flex items-center gap-1">
                <Building2 className="w-3 h-3" /> Building / Block
              </label>
              <input
                type="text"
                value={buildingBlock}
                onChange={(e) => setBuildingBlock(e.target.value)}
                placeholder="e.g. Block A"
                className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-xs text-slate-500 mb-1 flex items-center gap-1">
                <Layers className="w-3 h-3" /> Floor
              </label>
              <input
                type="text"
                value={floor}
                onChange={(e) => setFloor(e.target.value)}
                placeholder="e.g. Ground / 2nd"
                className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-xs text-slate-500 mb-1 flex items-center gap-1">
                <DoorClosed className="w-3 h-3" /> Room / Area
              </label>
              <input
                type="text"
                value={roomArea}
                onChange={(e) => setRoomArea(e.target.value)}
                placeholder="e.g. Room 201"
                className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
              />
            </div>
          </div>
          <div className="mt-3">
            <label className="text-xs text-slate-500 mb-1 flex items-center gap-1">
              <MapPin className="w-3 h-3" /> Select from Campus Map
            </label>
            <select
              value={mapNodeId}
              onChange={(e) => setMapNodeId(e.target.value)}
              className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
            >
              <option value="">— Choose map location (optional) —</option>
              {nodes.map((n) => (
                <option key={n.id} value={n.id}>{n.label}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Description */}
        <div>
          <label className="text-xs text-slate-500 mb-1 block">Problem Description</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe the issue in detail. What did you see? When did you notice it? Is anyone in danger?"
            rows={4}
            className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none resize-none"
          />
        </div>

        {/* Photo upload */}
        <div>
          <label className="text-xs text-slate-500 mb-1.5 block">Upload Photo (optional, max 5 MB)</label>
          {photoPreview ? (
            <div className="relative rounded-lg border border-slate-700 overflow-hidden">
              <img src={photoPreview} alt="Report preview" className="w-full max-h-48 object-cover" />
              <button
                onClick={clearPhoto}
                className="absolute top-2 right-2 flex items-center justify-center w-7 h-7 rounded-lg bg-black/60 text-white hover:bg-black/80 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex flex-col items-center justify-center w-full rounded-lg border-2 border-dashed border-slate-700 hover:border-amber-500/50 py-6 text-slate-500 hover:text-slate-400 transition-colors"
            >
              <Upload className="w-6 h-6 mb-1.5" />
              <span className="text-xs">Click to upload a photo of the problem</span>
            </button>
          )}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handlePhotoSelect}
            className="hidden"
          />
        </div>

        {/* Priority */}
        <div>
          <label className="text-xs text-slate-500 mb-1.5 block">Priority</label>
          <div className="grid grid-cols-4 gap-2">
            {PRIORITIES.map((p) => {
              const active = priority === p.value;
              return (
                <button
                  key={p.value}
                  onClick={() => setPriority(p.value)}
                  className={`rounded-lg border px-2 py-2.5 text-sm font-semibold transition-all ${
                    active
                      ? `${p.bg} ${p.border} ${p.color}`
                      : 'border-slate-700 text-slate-400 hover:border-slate-600'
                  }`}
                >
                  {p.value}
                </button>
              );
            })}
          </div>
        </div>

        {/* Message */}
        {msg && (
          <div
            className={`rounded-lg px-3 py-2 text-sm ${
              msg.ok
                ? 'bg-green-500/10 border border-green-500/30 text-green-300'
                : 'bg-red-500/10 border border-red-500/30 text-red-300'
            }`}
          >
            {msg.text}
          </div>
        )}

        {/* Submit */}
        <button
          onClick={handleSubmit}
          disabled={submitting || uploading || !reporterName.trim()}
          className="flex items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-amber-600 to-orange-600 px-4 py-2.5 text-sm font-semibold text-white hover:scale-[1.01] transition-transform disabled:opacity-40 disabled:cursor-not-allowed"
        >
          {submitting || uploading ? 'Submitting...' : 'Submit Report'}
          {submitting || uploading ? (
            <ImageIcon className="w-4 h-4 animate-pulse" />
          ) : (
            <Send className="w-4 h-4" />
          )}
        </button>
      </div>
    </div>
  );
}
