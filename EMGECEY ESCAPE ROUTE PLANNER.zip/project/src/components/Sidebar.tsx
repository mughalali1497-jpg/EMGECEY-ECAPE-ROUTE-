// ============================================================================
// Sidebar — Top-level navigation
// ----------------------------------------------------------------------------

import { Home, Map, Route, Siren, ShieldCheck, Users } from 'lucide-react';

export type PageId = 'home' | 'map' | 'planner' | 'emergency' | 'admin' | 'students';

interface SidebarProps {
  current: PageId;
  onNavigate: (page: PageId) => void;
}

const NAV_ITEMS: { id: PageId; label: string; icon: typeof Home; desc: string }[] = [
  { id: 'home', label: 'Home', icon: Home, desc: 'Overview & quick start' },
  { id: 'map', label: 'Campus Map', icon: Map, desc: 'Interactive evacuation map' },
  { id: 'planner', label: 'Route Planner', icon: Route, desc: 'Plan your escape route' },
  { id: 'emergency', label: 'Emergency Mode', icon: Siren, desc: 'Simplified emergency view' },
  { id: 'students', label: 'Student Panel', icon: Users, desc: 'Safety check-in & map access' },
  { id: 'admin', label: 'Admin Panel', icon: ShieldCheck, desc: 'Manage campus data' },
];

export default function Sidebar({ current, onNavigate }: SidebarProps) {
  return (
    <nav className="flex flex-col gap-1.5 p-3 h-full">
      <div className="px-3 py-4 mb-2">
        <div className="flex items-center gap-2.5">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-gradient-to-br from-red-500 to-orange-500 shadow-lg shadow-red-500/20">
            <Siren className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-white leading-tight">Escape Route</h1>
            <p className="text-[11px] text-slate-400 leading-tight">Planner</p>
          </div>
        </div>
      </div>

      {NAV_ITEMS.map((item) => {
        const Icon = item.icon;
        const active = current === item.id;
        return (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={`group flex items-center gap-3 rounded-lg px-3 py-2.5 text-left transition-all ${
              active
                ? 'bg-gradient-to-r from-red-500/20 to-orange-500/10 text-white border border-red-500/30'
                : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200 border border-transparent'
            }`}
          >
            <Icon
              className={`w-5 h-5 shrink-0 ${active ? 'text-red-400' : 'text-slate-500 group-hover:text-slate-300'}`}
            />
            <div className="min-w-0">
              <div className="text-sm font-semibold">{item.label}</div>
              <div className="text-[11px] text-slate-500 truncate">{item.desc}</div>
            </div>
          </button>
        );
      })}

      <div className="mt-auto rounded-lg bg-slate-800/50 p-3 text-[11px] text-slate-500 leading-relaxed">
        <p className="font-semibold text-slate-400 mb-1">Academic Project</p>
        <p>Dijkstra-based evacuation prototype. Not a certified safety system.</p>
      </div>
    </nav>
  );
}
