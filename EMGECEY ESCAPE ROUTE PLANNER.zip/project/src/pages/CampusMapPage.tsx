// ============================================================================
// CampusMapPage — Interactive map with location/exit selection + blocking
// ----------------------------------------------------------------------------

import { useState, useMemo } from 'react';
import { MapPin, Flag, Ban, MousePointerClick, Trash2, Info } from 'lucide-react';
import CampusMap from '@/components/CampusMap';
import { useApp } from '@/context/AppContext';
import type { PageId } from '@/components/Sidebar';

interface CampusMapPageProps {
  onNavigate: (page: PageId) => void;
}

type Mode = 'start' | 'target';

export default function CampusMapPage({ onNavigate }: CampusMapPageProps) {
  const {
    nodes,
    nodeMap,
    startNodeId,
    targetNodeId,
    setStartNodeId,
    setTargetNodeId,
    blockages,
    isNodeBlocked,
    isEdgeBlocked,
    computeNearestExit,
  } = useApp();

  const [mode, setMode] = useState<Mode>('start');
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleSelectNode = (nodeId: string) => {
    if (mode === 'start') {
      setStartNodeId(nodeId);
      setFeedback(`Start location set to: ${nodeMap.get(nodeId)?.label}`);
    } else if (mode === 'target') {
      setTargetNodeId(nodeId);
      setFeedback(`Destination exit set to: ${nodeMap.get(nodeId)?.label}`);
    }
  };

  const autoDetectExit = () => {
    if (!startNodeId) {
      setFeedback('Please select your current location first.');
      return;
    }
    const result = computeNearestExit();
    if (result) {
      setTargetNodeId(result.targetId);
      setFeedback(`Nearest exit detected: ${nodeMap.get(result.targetId)?.label}`);
    } else {
      setFeedback('No safe exit found — all paths may be blocked.');
    }
  };

  const routeEdgeKeys = useMemo(() => {
    const result = computeNearestExit();
    if (!result || !startNodeId) return new Set<string>();
    const keys = new Set<string>();
    for (let i = 0; i < result.route.path.length - 1; i++) {
      keys.add([result.route.path[i], result.route.path[i + 1]].sort().join('|'));
    }
    return keys;
  }, [computeNearestExit, startNodeId]);

  const routePath = useMemo(() => {
    const result = computeNearestExit();
    if (!result || !startNodeId) return new Set<string>();
    return new Set(result.route.path);
  }, [computeNearestExit, startNodeId]);

  const modeButtons: { id: Mode; label: string; icon: typeof MapPin; color: string }[] = [
    { id: 'start', label: 'Set Start', icon: MapPin, color: 'sky' },
    { id: 'target', label: 'Set Exit', icon: Flag, color: 'purple' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-white">Campus Map</h1>
          <p className="text-sm text-slate-400">Click on the map to select your start location or nearest exit</p>
        </div>
        <button
          onClick={autoDetectExit}
          className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-green-600 to-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:scale-[1.02] transition-transform"
        >
          <MapPin className="w-4 h-4" />
          Auto-detect Nearest Exit
        </button>
      </div>

      {/* Mode selector */}
      <div className="flex flex-wrap gap-2">
        {modeButtons.map((btn) => {
          const Icon = btn.icon;
          const active = mode === btn.id;
          const colorClasses: Record<string, string> = {
            sky: active ? 'bg-sky-500/20 border-sky-500/50 text-sky-300' : 'border-slate-700 text-slate-400 hover:text-sky-300',
            purple: active ? 'bg-purple-500/20 border-purple-500/50 text-purple-300' : 'border-slate-700 text-slate-400 hover:text-purple-300',
          };
          return (
            <button
              key={btn.id}
              onClick={() => setMode(btn.id)}
              className={`flex items-center gap-2 rounded-lg border px-4 py-2 text-sm font-semibold transition-colors ${colorClasses[btn.color]}`}
            >
              <Icon className="w-4 h-4" />
              {btn.label}
            </button>
          );
        })}
      </div>

      {/* Status bar */}
      <div className="flex flex-wrap items-center gap-4 rounded-lg bg-slate-800/50 border border-slate-700 px-4 py-2.5 text-sm">
        <span className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-sky-500" />
          <span className="text-slate-400">Start:</span>
          <span className="text-white font-semibold">
            {startNodeId ? nodeMap.get(startNodeId)?.label : 'Not selected'}
          </span>
        </span>
        <span className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-purple-500" />
          <span className="text-slate-400">Exit:</span>
          <span className="text-white font-semibold">
            {targetNodeId ? nodeMap.get(targetNodeId)?.label : 'Not selected'}
          </span>
        </span>
        {blockages.length > 0 && (
          <span className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-red-500" />
            <span className="text-slate-400">Blocked (admin):</span>
            <span className="text-white font-semibold">{blockages.length}</span>
          </span>
        )}
        {feedback && (
          <span className="flex items-center gap-1.5 text-xs text-amber-300 ml-auto">
            <MousePointerClick className="w-3.5 h-3.5" />
            {feedback}
          </span>
        )}
      </div>

      {/* Map */}
      <CampusMap
        routePath={routePath}
        routeEdgeKeys={routeEdgeKeys}
        onSelectNode={handleSelectNode}
        selectionMode={mode}
      />

      {/* Active blockages (read-only — managed from Admin Panel) */}
      {blockages.length > 0 && (
        <div className="rounded-xl bg-slate-800/50 border border-slate-700 p-4">
          <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
            <Ban className="w-4 h-4 text-red-400" />
            Active Blockages ({blockages.length})
          </h3>
          <div className="flex flex-wrap gap-2">
            {blockages.map((b) => {
              const label =
                b.kind === 'node'
                  ? nodeMap.get(b.refId)?.label ?? b.refId
                  : `Path ${b.refId}`;
              return (
                <span
                  key={b.id}
                  className="flex items-center gap-2 rounded-lg bg-red-500/10 border border-red-500/20 px-3 py-1.5 text-xs text-red-300"
                >
                  <Ban className="w-3 h-3" />
                  {label}
                </span>
              );
            })}
          </div>
          <p className="text-[11px] text-slate-500 mt-2">
            Blockages are managed by administrators from the Admin Panel.
          </p>
        </div>
      )}

      {/* Navigation hint */}
      {startNodeId && targetNodeId && (
        <div className="flex items-center justify-between rounded-xl bg-gradient-to-r from-green-600/20 to-emerald-600/10 border border-green-500/30 px-4 py-3">
          <span className="flex items-center gap-2 text-sm text-green-300">
            <Info className="w-4 h-4" />
            Ready to plan your escape route.
          </span>
          <button
            onClick={() => onNavigate('planner')}
            className="rounded-lg bg-green-600 px-4 py-1.5 text-sm font-semibold text-white hover:bg-green-500 transition-colors"
          >
            Go to Route Planner →
          </button>
        </div>
      )}
    </div>
  );
}
