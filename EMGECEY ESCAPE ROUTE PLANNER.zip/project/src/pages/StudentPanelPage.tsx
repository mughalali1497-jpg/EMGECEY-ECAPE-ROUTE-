// ============================================================================
// StudentPanelPage — Student safety check-in + campus map access
// ----------------------------------------------------------------------------
// This page is only functional when an admin has declared an active emergency.
// Students can:
//   - See the current emergency alert (type + description)
//   - Check in as Safe, In Danger, or Evacuating with their name + location
//   - Edit / update their submitted status at any time
//   - Delete their own check-in data
//   - View the campus map with escape route visualization
// When no emergency is active, the page shows a calm "no emergency" state.
// ============================================================================

import { useState, useMemo } from 'react';
import {
  Users,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  Siren,
  Map as MapIcon,
  MapPin,
  Send,
  Lock,
  Clock,
  Footprints,
  Route as RouteIcon,
  Phone,
  Pencil,
  Trash2,
  X,
  FileText,
  Flag,
  Image as ImageIcon,
} from 'lucide-react';
import CampusMap from '@/components/CampusMap';
import ReportProblemForm from '@/components/ReportProblemForm';
import { useEmergency, type StudentSafetyStatus, type StudentStatus, type ProblemReport, type ProblemPriority } from '@/context/EmergencyContext';
import { useApp } from '@/context/AppContext';
import type { PageId } from '@/components/Sidebar';

interface StudentPanelPageProps {
  onNavigate: (page: PageId) => void;
}

const STATUS_CONFIG: Record<
  StudentSafetyStatus,
  { label: string; color: string; bg: string; border: string; icon: typeof ShieldCheck }
> = {
  safe: {
    label: 'Safe',
    color: 'text-green-300',
    bg: 'bg-green-500/10',
    border: 'border-green-500/30',
    icon: CheckCircle2,
  },
  in_danger: {
    label: 'In Danger',
    color: 'text-red-300',
    bg: 'bg-red-500/10',
    border: 'border-red-500/30',
    icon: AlertTriangle,
  },
  evacuating: {
    label: 'Evacuating',
    color: 'text-amber-300',
    bg: 'bg-amber-500/10',
    border: 'border-amber-500/30',
    icon: Footprints,
  },
};

function formatTime(seconds: number) {
  if (seconds < 60) return `${seconds}s`;
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}m ${s}s`;
}

const PRIORITY_STYLE: Record<ProblemPriority, { color: string; bg: string; border: string }> = {
  Low: { color: 'text-green-300', bg: 'bg-green-500/10', border: 'border-green-500/30' },
  Medium: { color: 'text-sky-300', bg: 'bg-sky-500/10', border: 'border-sky-500/30' },
  High: { color: 'text-amber-300', bg: 'bg-amber-500/10', border: 'border-amber-500/30' },
  Critical: { color: 'text-red-300', bg: 'bg-red-500/10', border: 'border-red-500/30' },
};

const REPORT_STATUS_STYLE: Record<string, { color: string; bg: string; border: string; label: string }> = {
  pending: { color: 'text-amber-300', bg: 'bg-amber-500/10', border: 'border-amber-500/30', label: 'Pending' },
  reviewed: { color: 'text-sky-300', bg: 'bg-sky-500/10', border: 'border-sky-500/30', label: 'Reviewed' },
  resolved: { color: 'text-green-300', bg: 'bg-green-500/10', border: 'border-green-500/30', label: 'Resolved' },
};

export default function StudentPanelPage({ onNavigate }: StudentPanelPageProps) {
  const {
    emergencyState,
    studentStatuses,
    problemReports,
    deleteProblemReport,
    submitStudentStatus,
    updateStudentStatus,
    deleteStudentStatus,
    loading,
  } = useEmergency();
  const { nodes, startNodeId, setStartNodeId, computeNearestExit, nodeMap } = useApp();

  const [studentName, setStudentName] = useState('');
  const [studentId, setStudentId] = useState('');
  const [location, setLocation] = useState('');
  const [status, setStatus] = useState<StudentSafetyStatus>('evacuating');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitMsg, setSubmitMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [mapUnlocked, setMapUnlocked] = useState(false);
  const [showReportForm, setShowReportForm] = useState(false);
  const [viewingReport, setViewingReport] = useState<ProblemReport | null>(null);
  const [reportDeletingId, setReportDeletingId] = useState<string | null>(null);
  const [reportDeleteBusy, setReportDeleteBusy] = useState(false);

  // Edit modal state
  const [editingEntry, setEditingEntry] = useState<StudentStatus | null>(null);
  const [editStatus, setEditStatus] = useState<StudentSafetyStatus>('safe');
  const [editLocation, setEditLocation] = useState('');
  const [editNotes, setEditNotes] = useState('');
  const [editBusy, setEditBusy] = useState(false);
  const [editMsg, setEditMsg] = useState<{ ok: boolean; text: string } | null>(null);

  // Delete confirmation state
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);

  const isActive = emergencyState?.is_active ?? false;

  const nearest = useMemo(() => computeNearestExit(), [computeNearestExit]);

  const routePath = useMemo(
    () => (nearest ? new Set(nearest.route.path) : new Set<string>()),
    [nearest],
  );
  const routeEdgeKeys = useMemo(() => {
    if (!nearest) return new Set<string>();
    const keys = new Set<string>();
    for (let i = 0; i < nearest.route.path.length - 1; i++) {
      keys.add([nearest.route.path[i], nearest.route.path[i + 1]].sort().join('|'));
    }
    return keys;
  }, [nearest]);

  const statusCounts = useMemo(() => {
    const counts = { safe: 0, in_danger: 0, evacuating: 0 };
    for (const s of studentStatuses) {
      counts[s.status]++;
    }
    return counts;
  }, [studentStatuses]);

  const handleSubmit = async () => {
    if (!studentName.trim()) {
      setSubmitMsg({ ok: false, text: 'Please enter your name.' });
      return;
    }
    setSubmitting(true);
    setSubmitMsg(null);
    const result = await submitStudentStatus({
      student_name: studentName.trim(),
      student_id_number: studentId.trim(),
      location: location.trim(),
      status,
      notes: notes.trim(),
    });
    setSubmitting(false);
    if (result.success) {
      setSubmitMsg({ ok: true, text: 'Your status has been submitted. Stay safe!' });
      setNotes('');
    } else {
      setSubmitMsg({ ok: false, text: result.error ?? 'Failed to submit. Please try again.' });
    }
  };

  const openEditModal = (entry: StudentStatus) => {
    setEditingEntry(entry);
    setEditStatus(entry.status);
    setEditLocation(entry.location);
    setEditNotes(entry.notes);
    setEditMsg(null);
  };

  const closeEditModal = () => {
    setEditingEntry(null);
    setEditMsg(null);
  };

  const handleEditSave = async () => {
    if (!editingEntry) return;
    setEditBusy(true);
    setEditMsg(null);
    const result = await updateStudentStatus(editingEntry.id, {
      status: editStatus,
      location: editLocation,
      notes: editNotes.trim(),
    });
    setEditBusy(false);
    if (result.success) {
      setEditMsg({ ok: true, text: 'Status updated successfully.' });
      setTimeout(() => closeEditModal(), 1000);
    } else {
      setEditMsg({ ok: false, text: result.error ?? 'Failed to update. Please try again.' });
    }
  };

  const handleDelete = async (id: string) => {
    setDeleteBusy(true);
    try {
      await deleteStudentStatus(id);
      setDeletingId(null);
    } catch {
      setEditMsg({ ok: false, text: 'Failed to delete entry.' });
    }
    setDeleteBusy(false);
  };

  const handleReportDelete = async (id: string) => {
    setReportDeleteBusy(true);
    try {
      await deleteProblemReport(id);
      setReportDeletingId(null);
    } catch {
      setEditMsg({ ok: false, text: 'Failed to delete report.' });
    }
    setReportDeleteBusy(false);
  };

  const renderReportCard = (r: ProblemReport) => {
    const pStyle = PRIORITY_STYLE[r.priority];
    const sStyle = REPORT_STATUS_STYLE[r.status] ?? REPORT_STATUS_STYLE.pending;
    return (
      <div
        key={r.id}
        className="rounded-lg bg-slate-900/40 border border-slate-700/50 px-3 py-3"
      >
        <div className="flex items-start gap-3">
          <div className={`flex items-center justify-center w-8 h-8 rounded-lg ${pStyle.bg} ${pStyle.border} border shrink-0`}>
            <Flag className={`w-4 h-4 ${pStyle.color}`} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <p className="text-sm font-semibold text-white">{r.problem_type}</p>
              <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${pStyle.bg} ${pStyle.color} border ${pStyle.border}`}>
                {r.priority}
              </span>
              <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${sStyle.bg} ${sStyle.color} border ${sStyle.border}`}>
                {sStyle.label}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">
              {r.building_block && `${r.building_block} · `}
              {r.floor && `${r.floor} · `}
              {r.room_area}
              {r.map_node_id && ` · ${nodeMap.get(r.map_node_id)?.label ?? r.map_node_id}`}
            </p>
            {r.description && (
              <p className="text-xs text-slate-400 mt-1 line-clamp-2">{r.description}</p>
            )}
            {r.photo_url && (
              <img src={r.photo_url} alt="Report" className="mt-2 rounded-lg max-h-32 object-cover" />
            )}
            <p className="text-[10px] text-slate-600 mt-1">
              By {r.student_name}{r.student_roll_number && ` (${r.student_roll_number})`}{r.student_mobile && ` · ${r.student_mobile}`} — {new Date(r.created_at).toLocaleString()}
            </p>
          </div>
          <div className="flex flex-col gap-1 shrink-0">
            <button
              onClick={() => setViewingReport(r)}
              className="flex items-center justify-center w-7 h-7 rounded-lg text-slate-400 hover:text-sky-400 hover:bg-sky-500/10 transition-colors"
              title="View details"
            >
              <FileText className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setReportDeletingId(r.id)}
              className="flex items-center justify-center w-7 h-7 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"
              title="Delete report"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    );
  };

  // --- No active emergency: locked state ---
  if (!isActive) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-sky-600 to-blue-700">
            <Users className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">Student Panel</h1>
            <p className="text-sm text-slate-400">Safety check-in and campus map access</p>
          </div>
        </div>

        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="flex items-center justify-center w-20 h-20 rounded-2xl bg-green-500/15 border border-green-500/30 mb-5">
            <ShieldCheck className="w-10 h-10 text-green-400" />
          </div>
          <h2 className="text-xl font-bold text-white mb-2">No Active Emergency</h2>
          <p className="text-sm text-slate-400 max-w-md mb-6">
            The campus is operating normally. The safety check-in and emergency map
            will become available when an administrator declares an emergency.
          </p>
          <div className="flex items-center gap-2 rounded-lg bg-slate-800/50 border border-slate-700 px-4 py-2.5 text-sm text-slate-400">
            <Lock className="w-4 h-4 text-slate-500" />
            Emergency check-in and evacuation map are locked until activated by admin.
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div className="rounded-xl bg-slate-800/50 border border-slate-700 p-4 text-center">
            <CheckCircle2 className="w-5 h-5 text-green-400 mx-auto mb-1.5" />
            <p className="text-2xl font-bold text-white">{statusCounts.safe}</p>
            <p className="text-xs text-slate-500">Marked Safe</p>
          </div>
          <div className="rounded-xl bg-slate-800/50 border border-slate-700 p-4 text-center">
            <Footprints className="w-5 h-5 text-amber-400 mx-auto mb-1.5" />
            <p className="text-2xl font-bold text-white">{statusCounts.evacuating}</p>
            <p className="text-xs text-slate-500">Evacuating</p>
          </div>
          <div className="rounded-xl bg-slate-800/50 border border-slate-700 p-4 text-center">
            <AlertTriangle className="w-5 h-5 text-red-400 mx-auto mb-1.5" />
            <p className="text-2xl font-bold text-white">{statusCounts.in_danger}</p>
            <p className="text-xs text-slate-500">In Danger</p>
          </div>
        </div>

        {/* ===== Report a Problem Section (always available) ===== */}
        <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="flex items-center gap-2 text-sm font-bold text-white">
              <FileText className="w-4 h-4 text-amber-400" />
              Report a Safety Problem
            </h2>
            <button
              onClick={() => setShowReportForm((v) => !v)}
              className={`flex items-center gap-2 rounded-lg px-4 py-1.5 text-xs font-semibold transition-colors ${
                showReportForm
                  ? 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                  : 'bg-amber-600 text-white hover:bg-amber-500'
              }`}
            >
              {showReportForm ? (
                <>
                  <X className="w-3.5 h-3.5" />
                  Close Form
                </>
              ) : (
                <>
                  <FileText className="w-3.5 h-3.5" />
                  New Report
                </>
              )}
            </button>
          </div>

          <p className="text-xs text-slate-400 mb-4 leading-relaxed">
            You can report a safety problem at any time — even when no emergency is active.
            Your report will be reviewed by campus administrators.
          </p>

          {showReportForm && (
            <div className="mb-4">
              <ReportProblemForm onSubmitted={() => setShowReportForm(false)} />
            </div>
          )}

          {problemReports.length > 0 ? (
            <div>
              <p className="text-xs text-slate-500 mb-2">
                Submitted Reports ({problemReports.length})
              </p>
              <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
                {problemReports.map((r) => renderReportCard(r))}
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <FileText className="w-8 h-8 text-slate-600 mx-auto mb-2" />
              <p className="text-sm text-slate-400">
                No reports submitted yet. Click "New Report" to file a safety problem.
              </p>
            </div>
          )}
        </div>
      </div>
    );
  }

  // --- Active emergency: full student panel ---
  return (
    <div className="space-y-4">
      {/* Emergency alert banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-red-600 to-orange-600 p-5">
        <div className="absolute inset-0 opacity-20 animate-pulse bg-red-400" />
        <div className="relative flex items-center gap-4">
          <div className="flex items-center justify-center w-14 h-14 rounded-xl bg-white/20 backdrop-blur-sm">
            <Siren className="w-8 h-8 text-white animate-pulse" />
          </div>
          <div className="flex-1">
            <h1 className="text-2xl font-black text-white tracking-wide">
              {emergencyState?.emergency_type || 'EMERGENCY'} — STUDENT PANEL
            </h1>
            <p className="text-white/80 text-sm mt-0.5">
              {emergencyState?.description || 'An emergency has been declared. Please check in immediately.'}
            </p>
          </div>
        </div>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-xl bg-green-500/10 border border-green-500/30 p-4 text-center">
          <CheckCircle2 className="w-5 h-5 text-green-400 mx-auto mb-1.5" />
          <p className="text-2xl font-bold text-white">{statusCounts.safe}</p>
          <p className="text-xs text-slate-500">Marked Safe</p>
        </div>
        <div className="rounded-xl bg-amber-500/10 border border-amber-500/30 p-4 text-center">
          <Footprints className="w-5 h-5 text-amber-400 mx-auto mb-1.5" />
          <p className="text-2xl font-bold text-white">{statusCounts.evacuating}</p>
          <p className="text-xs text-slate-500">Evacuating</p>
        </div>
        <div className="rounded-xl bg-red-500/10 border border-red-500/30 p-4 text-center">
          <AlertTriangle className="w-5 h-5 text-red-400 mx-auto mb-1.5" />
          <p className="text-2xl font-bold text-white">{statusCounts.in_danger}</p>
          <p className="text-xs text-slate-500">In Danger</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Check-in form */}
        <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-5">
          <h2 className="flex items-center gap-2 text-sm font-bold text-white mb-4">
            <Send className="w-4 h-4 text-sky-400" />
            Submit Your Safety Status
          </h2>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-slate-500 mb-1 block">Your Name *</label>
                <input
                  type="text"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  placeholder="Full name"
                  className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-sky-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">Roll Number</label>
                <input
                  type="text"
                  value={studentId}
                  onChange={(e) => setStudentId(e.target.value)}
                  placeholder="e.g. CS21B001"
                  className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-sky-500 focus:outline-none"
                />
              </div>
            </div>
            <div>
              <label className="text-xs text-slate-500 mb-1 block">Your Current Location</label>
              <select
                value={location}
                onChange={(e) => {
                  setLocation(e.target.value);
                  setStartNodeId(e.target.value || null);
                }}
                className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-sky-500 focus:outline-none"
              >
                <option value="">— Select your location —</option>
                {nodes.map((n) => (
                  <option key={n.id} value={n.id}>{n.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-xs text-slate-500 mb-1.5 block">Your Status</label>
              <div className="grid grid-cols-3 gap-2">
                {(Object.keys(STATUS_CONFIG) as StudentSafetyStatus[]).map((key) => {
                  const cfg = STATUS_CONFIG[key];
                  const Icon = cfg.icon;
                  const active = status === key;
                  return (
                    <button
                      key={key}
                      onClick={() => setStatus(key)}
                      className={`flex flex-col items-center gap-1.5 rounded-lg border px-2 py-3 text-sm font-semibold transition-all ${
                        active
                          ? `${cfg.bg} ${cfg.border} ${cfg.color}`
                          : 'border-slate-700 text-slate-400 hover:border-slate-600'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      {cfg.label}
                    </button>
                  );
                })}
              </div>
            </div>
            <div>
              <label className="text-xs text-slate-500 mb-1 block">Additional Notes (optional)</label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Trapped in Lab 1, need immediate help"
                rows={2}
                className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-sky-500 focus:outline-none resize-none"
              />
            </div>
            {submitMsg && (
              <div
                className={`rounded-lg px-3 py-2 text-sm ${
                  submitMsg.ok
                    ? 'bg-green-500/10 border border-green-500/30 text-green-300'
                    : 'bg-red-500/10 border border-red-500/30 text-red-300'
                }`}
              >
                {submitMsg.text}
              </div>
            )}
            <button
              onClick={handleSubmit}
              disabled={submitting || !studentName.trim()}
              className="flex items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-sky-600 to-blue-600 px-4 py-2.5 text-sm font-semibold text-white hover:scale-[1.01] transition-transform disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {submitting ? 'Submitting...' : 'Submit Status'}
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Escape route info */}
        <div className="space-y-3">
          {nearest && location ? (
            <>
              <div className="rounded-2xl bg-green-500/10 border border-green-500/30 p-4">
                <h3 className="flex items-center gap-2 text-sm font-bold text-white mb-3">
                  <RouteIcon className="w-4 h-4 text-green-400" />
                  Your Escape Route
                </h3>
                <div className="grid grid-cols-3 gap-2 mb-3">
                  <div className="rounded-lg bg-slate-900/60 border border-slate-700 p-2.5 text-center">
                    <MapIcon className="w-4 h-4 text-green-400 mx-auto mb-1" />
                    <p className="text-sm font-bold text-white">{nearest.route.distance}m</p>
                    <p className="text-[10px] text-slate-500">Distance</p>
                  </div>
                  <div className="rounded-lg bg-slate-900/60 border border-slate-700 p-2.5 text-center">
                    <Clock className="w-4 h-4 text-amber-400 mx-auto mb-1" />
                    <p className="text-sm font-bold text-white">{formatTime(nearest.route.timeSeconds)}</p>
                    <p className="text-[10px] text-slate-500">Est. Time</p>
                  </div>
                  <div className="rounded-lg bg-slate-900/60 border border-slate-700 p-2.5 text-center">
                    <ShieldCheck className="w-4 h-4 text-sky-400 mx-auto mb-1" />
                    <p className="text-sm font-bold text-white">{nodeMap.get(nearest.targetId)?.label ?? '—'}</p>
                    <p className="text-[10px] text-slate-500">Nearest Exit</p>
                  </div>
                </div>
                <div className="rounded-lg bg-slate-900/60 border border-slate-700 p-3">
                  <p className="text-xs text-slate-400 mb-1">Route:</p>
                  <p className="text-sm text-slate-200 leading-relaxed">
                    {nearest.route.path
                      .map((id) => nodeMap.get(id)?.label ?? id)
                      .join(' → ')}
                  </p>
                </div>
              </div>
            </>
          ) : (
            <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-4">
              <h3 className="flex items-center gap-2 text-sm font-bold text-white mb-2">
                <MapPin className="w-4 h-4 text-sky-400" />
                Your Escape Route
              </h3>
              <p className="text-sm text-slate-400">
                Select your current location above to see your personalized escape route.
              </p>
            </div>
          )}

          {/* Safety instructions */}
          <div className="rounded-2xl bg-red-500/10 border border-red-500/30 p-4">
            <h3 className="flex items-center gap-2 text-sm font-bold text-red-300 mb-2">
              <AlertTriangle className="w-4 h-4" />
              Safety Instructions
            </h3>
            <ul className="space-y-1.5 text-xs text-slate-300">
              <li>• Stay calm and walk quickly — do not run.</li>
              <li>• Follow the green path on the map below.</li>
              <li>• Avoid areas marked with red hazard indicators.</li>
              <li>• Do not use elevators — use stairs only.</li>
              <li>• Call 112 if you need immediate help.</li>
            </ul>
          </div>

          {/* Emergency contacts */}
          <div className="grid grid-cols-3 gap-2">
            {[
              { label: 'Fire', num: '101' },
              { label: 'Ambulance', num: '102' },
              { label: 'Helpline', num: '112' },
            ].map((c) => (
              <a
                key={c.label}
                href={`tel:${c.num}`}
                className="flex flex-col items-center rounded-lg bg-slate-800 border border-slate-700 px-3 py-2.5 hover:border-red-500/40 transition-colors"
              >
                <Phone className="w-4 h-4 text-red-400 mb-1" />
                <span className="text-[11px] text-slate-500">{c.label}</span>
                <span className="text-sm font-bold text-white">{c.num}</span>
              </a>
            ))}
          </div>
        </div>
      </div>

      {/* Campus map access — locked until student selects location */}
      <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="flex items-center gap-2 text-sm font-bold text-white">
            <MapIcon className="w-4 h-4 text-green-400" />
            Campus Evacuation Map
          </h2>
          {!mapUnlocked ? (
            <button
              onClick={() => setMapUnlocked(true)}
              className="flex items-center gap-2 rounded-lg bg-green-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-green-500 transition-colors"
            >
              <MapIcon className="w-3.5 h-3.5" />
              Show Map
            </button>
          ) : (
            <button
              onClick={() => setMapUnlocked(false)}
              className="flex items-center gap-2 rounded-lg bg-slate-700 px-4 py-1.5 text-xs font-semibold text-slate-300 hover:bg-slate-600 transition-colors"
            >
              <Lock className="w-3.5 h-3.5" />
              Hide Map
            </button>
          )}
        </div>
        {mapUnlocked ? (
          <CampusMap routePath={routePath} routeEdgeKeys={routeEdgeKeys} />
        ) : (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="flex items-center justify-center w-14 h-14 rounded-xl bg-slate-700/50 mb-3">
              <Lock className="w-7 h-7 text-slate-500" />
            </div>
            <p className="text-sm text-slate-400 max-w-md">
              Click "Show Map" to view the campus evacuation map with your highlighted escape route.
            </p>
            <button
              onClick={() => onNavigate('emergency')}
              className="mt-4 flex items-center gap-2 text-sm font-semibold text-green-400 hover:text-green-300 transition-colors"
            >
              Or go to full Emergency Mode →
            </button>
          </div>
        )}
      </div>

      {/* ===== Report a Problem Section ===== */}
      <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="flex items-center gap-2 text-sm font-bold text-white">
            <FileText className="w-4 h-4 text-amber-400" />
            Report a Safety Problem
          </h2>
          <button
            onClick={() => setShowReportForm((v) => !v)}
            className={`flex items-center gap-2 rounded-lg px-4 py-1.5 text-xs font-semibold transition-colors ${
              showReportForm
                ? 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                : 'bg-amber-600 text-white hover:bg-amber-500'
            }`}
          >
            {showReportForm ? (
              <>
                <X className="w-3.5 h-3.5" />
                Close Form
              </>
            ) : (
              <>
                <FileText className="w-3.5 h-3.5" />
                New Report
              </>
            )}
          </button>
        </div>

        {showReportForm && (
          <div className="mb-4">
            <ReportProblemForm onSubmitted={() => setShowReportForm(false)} />
          </div>
        )}

        {problemReports.length > 0 ? (
          <div>
            <p className="text-xs text-slate-500 mb-2">
              Submitted Reports ({problemReports.length})
            </p>
            <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
              {problemReports.map((r) => renderReportCard(r))}
            </div>
          </div>
        ) : (
          <div className="text-center py-8">
            <FileText className="w-8 h-8 text-slate-600 mx-auto mb-2" />
            <p className="text-sm text-slate-400">
              No reports submitted yet. Click "New Report" to file a safety problem.
            </p>
          </div>
        )}
      </div>

      {/* Recent check-ins with edit + delete */}
      {studentStatuses.length > 0 && (
        <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-5">
          <h2 className="text-sm font-bold text-white mb-4">
            Student Check-ins ({studentStatuses.length})
          </h2>
          <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
            {studentStatuses.map((s) => {
              const cfg = STATUS_CONFIG[s.status];
              const Icon = cfg.icon;
              return (
                <div
                  key={s.id}
                  className="flex items-center gap-3 rounded-lg bg-slate-900/40 border border-slate-700/50 px-3 py-2.5"
                >
                  <div className={`flex items-center justify-center w-8 h-8 rounded-lg ${cfg.bg} ${cfg.border} border shrink-0`}>
                    <Icon className={`w-4 h-4 ${cfg.color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">
                      {s.student_name}
                      {s.student_id_number && (
                        <span className="text-slate-500 font-normal ml-1.5">({s.student_id_number})</span>
                      )}
                    </p>
                    <p className="text-[11px] text-slate-500 truncate">
                      {s.location ? nodeMap.get(s.location)?.label ?? s.location : 'Location not set'}
                      {s.notes && ` · ${s.notes}`}
                    </p>
                  </div>
                  <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${cfg.bg} ${cfg.color} border ${cfg.border} shrink-0`}>
                    {cfg.label}
                  </span>
                  {/* Edit button */}
                  <button
                    onClick={() => openEditModal(s)}
                    className="flex items-center justify-center w-7 h-7 rounded-lg text-slate-400 hover:text-sky-400 hover:bg-sky-500/10 transition-colors shrink-0"
                    title="Edit status"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                  {/* Delete button */}
                  <button
                    onClick={() => setDeletingId(s.id)}
                    className="flex items-center justify-center w-7 h-7 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors shrink-0"
                    title="Delete check-in"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ===== Edit Modal ===== */}
      {editingEntry && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={closeEditModal}
          />
          <div className="relative w-full max-w-md rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl">
            {/* Modal header */}
            <div className="flex items-center justify-between border-b border-slate-700 px-5 py-3">
              <h3 className="flex items-center gap-2 text-sm font-bold text-white">
                <Pencil className="w-4 h-4 text-sky-400" />
                Edit Safety Status
              </h3>
              <button
                onClick={closeEditModal}
                className="text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal body */}
            <div className="p-5 space-y-4">
              {/* Student name (read-only) */}
              <div className="rounded-lg bg-slate-800/50 border border-slate-700 px-3 py-2">
                <p className="text-xs text-slate-500">Student</p>
                <p className="text-sm font-semibold text-white">
                  {editingEntry.student_name}
                  {editingEntry.student_id_number && (
                    <span className="text-slate-500 font-normal ml-1.5">({editingEntry.student_id_number})</span>
                  )}
                </p>
              </div>

              {/* Status selector */}
              <div>
                <label className="text-xs text-slate-500 mb-1.5 block">Update Status</label>
                <div className="grid grid-cols-3 gap-2">
                  {(Object.keys(STATUS_CONFIG) as StudentSafetyStatus[]).map((key) => {
                    const cfg = STATUS_CONFIG[key];
                    const Icon = cfg.icon;
                    const active = editStatus === key;
                    return (
                      <button
                        key={key}
                        onClick={() => setEditStatus(key)}
                        className={`flex flex-col items-center gap-1.5 rounded-lg border px-2 py-3 text-sm font-semibold transition-all ${
                          active
                            ? `${cfg.bg} ${cfg.border} ${cfg.color}`
                            : 'border-slate-700 text-slate-400 hover:border-slate-600'
                        }`}
                      >
                        <Icon className="w-5 h-5" />
                        {cfg.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Location selector */}
              <div>
                <label className="text-xs text-slate-500 mb-1 block">Location</label>
                <select
                  value={editLocation}
                  onChange={(e) => setEditLocation(e.target.value)}
                  className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-sky-500 focus:outline-none"
                >
                  <option value="">— Select location —</option>
                  {nodes.map((n) => (
                    <option key={n.id} value={n.id}>{n.label}</option>
                  ))}
                </select>
              </div>

              {/* Notes */}
              <div>
                <label className="text-xs text-slate-500 mb-1 block">Notes</label>
                <textarea
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  placeholder="Add or update notes..."
                  rows={2}
                  className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-sky-500 focus:outline-none resize-none"
                />
              </div>

              {/* Message */}
              {editMsg && (
                <div
                  className={`rounded-lg px-3 py-2 text-sm ${
                    editMsg.ok
                      ? 'bg-green-500/10 border border-green-500/30 text-green-300'
                      : 'bg-red-500/10 border border-red-500/30 text-red-300'
                  }`}
                >
                  {editMsg.text}
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-2">
                <button
                  onClick={handleEditSave}
                  disabled={editBusy}
                  className="flex-1 flex items-center justify-center gap-2 rounded-lg bg-sky-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-sky-500 transition-colors disabled:opacity-40"
                >
                  {editBusy ? 'Saving...' : 'Save Changes'}
                  <Pencil className="w-4 h-4" />
                </button>
                <button
                  onClick={closeEditModal}
                  className="rounded-lg bg-slate-700 px-4 py-2.5 text-sm font-semibold text-slate-300 hover:bg-slate-600 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===== Report View Modal ===== */}
      {viewingReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setViewingReport(null)}
          />
          <div className="relative w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-700 px-5 py-3 sticky top-0 bg-slate-900 z-10">
              <h3 className="flex items-center gap-2 text-sm font-bold text-white">
                <FileText className="w-4 h-4 text-amber-400" />
                Report Details
              </h3>
              <button
                onClick={() => setViewingReport(null)}
                className="text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 space-y-3">
              {(() => {
                const r = viewingReport;
                const pStyle = PRIORITY_STYLE[r.priority];
                const sStyle = REPORT_STATUS_STYLE[r.status] ?? REPORT_STATUS_STYLE.pending;
                return (
                  <>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`rounded-full px-3 py-1 text-xs font-bold ${pStyle.bg} ${pStyle.color} border ${pStyle.border}`}>
                        {r.priority} Priority
                      </span>
                      <span className={`rounded-full px-3 py-1 text-xs font-bold ${sStyle.bg} ${sStyle.color} border ${sStyle.border}`}>
                        {sStyle.label}
                      </span>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 mb-0.5">Problem Type</p>
                      <p className="text-sm font-bold text-white">{r.problem_type}</p>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <p className="text-xs text-slate-500 mb-0.5">Building / Block</p>
                        <p className="text-sm text-slate-200">{r.building_block || '—'}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 mb-0.5">Floor</p>
                        <p className="text-sm text-slate-200">{r.floor || '—'}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 mb-0.5">Room / Area</p>
                        <p className="text-sm text-slate-200">{r.room_area || '—'}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 mb-0.5">Map Location</p>
                        <p className="text-sm text-slate-200">
                          {r.map_node_id ? nodeMap.get(r.map_node_id)?.label ?? r.map_node_id : '—'}
                        </p>
                      </div>
                    </div>
                    {r.description && (
                      <div>
                        <p className="text-xs text-slate-500 mb-0.5">Description</p>
                        <p className="text-sm text-slate-300 leading-relaxed rounded-lg bg-slate-800/50 border border-slate-700 p-3">
                          {r.description}
                        </p>
                      </div>
                    )}
                    {r.photo_url && (
                      <div>
                        <p className="text-xs text-slate-500 mb-1 flex items-center gap-1">
                          <ImageIcon className="w-3 h-3" /> Attached Photo
                        </p>
                        <img src={r.photo_url} alt="Report" className="rounded-lg w-full max-h-64 object-cover" />
                      </div>
                    )}
                    <div className="rounded-lg bg-slate-800/50 border border-slate-700 p-3">
                      <p className="text-xs text-slate-500 mb-1">Reported By</p>
                      <p className="text-sm font-semibold text-white">{r.student_name}</p>
                      <p className="text-[11px] text-slate-500">
                        {r.student_roll_number && `Roll: ${r.student_roll_number} · `}
                        {r.student_mobile && `Mobile: ${r.student_mobile}`}
                      </p>
                      <p className="text-[10px] text-slate-600 mt-0.5">
                        {new Date(r.created_at).toLocaleString()}
                      </p>
                    </div>
                    {r.admin_notes && (
                      <div className="rounded-lg bg-sky-500/10 border border-sky-500/30 p-3">
                        <p className="text-xs text-sky-400 mb-0.5">Admin Notes</p>
                        <p className="text-sm text-slate-300">{r.admin_notes}</p>
                      </div>
                    )}
                    <div className="flex gap-2">
                      <button
                        onClick={() => setReportDeletingId(r.id)}
                        className="flex items-center gap-2 rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-500 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                        Delete Report
                      </button>
                      <button
                        onClick={() => setViewingReport(null)}
                        className="rounded-lg bg-slate-700 px-4 py-2 text-sm font-semibold text-slate-300 hover:bg-slate-600 transition-colors"
                      >
                        Close
                      </button>
                    </div>
                  </>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* ===== Report Delete Confirmation Modal ===== */}
      {reportDeletingId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setReportDeletingId(null)}
          />
          <div className="relative w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl">
            <div className="p-5 text-center">
              <div className="flex items-center justify-center w-14 h-14 rounded-xl bg-red-500/15 border border-red-500/30 mx-auto mb-4">
                <Trash2 className="w-7 h-7 text-red-400" />
              </div>
              <h3 className="text-sm font-bold text-white mb-2">Delete This Report?</h3>
              <p className="text-xs text-slate-400 mb-5">
                This will permanently remove the safety problem report. This action cannot be undone.
              </p>
              <div className="flex gap-2">
                <button
                  onClick={() => handleReportDelete(reportDeletingId)}
                  disabled={reportDeleteBusy}
                  className="flex-1 flex items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-red-500 transition-colors disabled:opacity-40"
                >
                  {reportDeleteBusy ? 'Deleting...' : 'Yes, Delete'}
                  <Trash2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setReportDeletingId(null)}
                  className="rounded-lg bg-slate-700 px-4 py-2.5 text-sm font-semibold text-slate-300 hover:bg-slate-600 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===== Delete Confirmation Modal ===== */}
      {deletingId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setDeletingId(null)}
          />
          <div className="relative w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl">
            <div className="p-5 text-center">
              <div className="flex items-center justify-center w-14 h-14 rounded-xl bg-red-500/15 border border-red-500/30 mx-auto mb-4">
                <Trash2 className="w-7 h-7 text-red-400" />
              </div>
              <h3 className="text-sm font-bold text-white mb-2">Delete This Check-in?</h3>
              <p className="text-xs text-slate-400 mb-5">
                This will permanently remove the student's safety status from the system.
                This action cannot be undone.
              </p>
              <div className="flex gap-2">
                <button
                  onClick={() => handleDelete(deletingId)}
                  disabled={deleteBusy}
                  className="flex-1 flex items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-red-500 transition-colors disabled:opacity-40"
                >
                  {deleteBusy ? 'Deleting...' : 'Yes, Delete'}
                  <Trash2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setDeletingId(null)}
                  className="rounded-lg bg-slate-700 px-4 py-2.5 text-sm font-semibold text-slate-300 hover:bg-slate-600 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
