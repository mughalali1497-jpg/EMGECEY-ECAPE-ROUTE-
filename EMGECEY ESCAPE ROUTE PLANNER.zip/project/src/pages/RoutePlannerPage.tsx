// ============================================================================
// RoutePlannerPage — Computes & displays primary + alternative escape routes
// ----------------------------------------------------------------------------

import { useMemo } from 'react';
import {
  Route,
  MapPin,
  Flag,
  Clock,
  Ruler,
  Footprints,
  AlertTriangle,
  Navigation,
  RotateCcw,
  ListOrdered,
  Siren,
} from 'lucide-react';
import CampusMap from '@/components/CampusMap';
import { useApp } from '@/context/AppContext';
import type { PageId } from '@/components/Sidebar';

interface RoutePlannerPageProps {
  onNavigate: (page: PageId) => void;
}

function formatTime(seconds: number) {
  if (seconds < 60) return `${seconds}s`;
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}m ${s}s`;
}

export default function RoutePlannerPage({ onNavigate }: RoutePlannerPageProps) {
  const {
    nodes,
    nodeMap,
    startNodeId,
    targetNodeId,
    setStartNodeId,
    setTargetNodeId,
    computeRouteToTarget,
    computeAlternativeRoute,
    computeNearestExit,
    blockages,
  } = useApp();

  const primaryRoute = useMemo(() => computeRouteToTarget(), [computeRouteToTarget]);
  const altRoute = useMemo(() => computeAlternativeRoute(), [computeAlternativeRoute]);

  const routeEdgeKeys = useMemo(() => {
    if (!primaryRoute) return new Set<string>();
    const keys = new Set<string>();
    for (let i = 0; i < primaryRoute.path.length - 1; i++) {
      keys.add([primaryRoute.path[i], primaryRoute.path[i + 1]].sort().join('|'));
    }
    return keys;
  }, [primaryRoute]);

  const routePath = useMemo(
    () => (primaryRoute ? new Set(primaryRoute.path) : new Set<string>()),
    [primaryRoute],
  );

  const autoExit = () => {
    const result = computeNearestExit();
    if (result) {
      setTargetNodeId(result.targetId);
    }
  };

  // No start selected
  if (!startNodeId) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <div className="flex items-center justify-center w-16 h-16 rounded-2xl bg-sky-500/20 border border-sky-500/30 mb-4">
          <MapPin className="w-8 h-8 text-sky-400" />
        </div>
        <h2 className="text-lg font-bold text-white mb-2">Select Your Location</h2>
        <p className="text-sm text-slate-400 max-w-md mb-6">
          Choose your current location on the campus map to start planning your escape route.
        </p>
        <button
          onClick={() => onNavigate('map')}
          className="rounded-xl bg-sky-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-sky-500 transition-colors"
        >
          Open Campus Map
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-white">Route Planner</h1>
          <p className="text-sm text-slate-400">Shortest safe path computed with Dijkstra\u2019s algorithm</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={autoExit}
            className="flex items-center gap-2 rounded-lg bg-slate-800 border border-slate-700 px-4 py-2 text-sm font-semibold text-slate-300 hover:bg-slate-700 transition-colors"
          >
            <Navigation className="w-4 h-4" />
            Nearest Exit
          </button>
          <button
            onClick={() => onNavigate('emergency')}
            className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-red-500 to-orange-500 px-4 py-2 text-sm font-semibold text-white hover:scale-[1.02] transition-transform"
          >
            <Siren className="w-4 h-4" />
            Emergency Mode
          </button>
        </div>
      </div>

      {/* Location selectors */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="rounded-xl bg-slate-800/50 border border-slate-700 p-4">
          <label className="text-xs text-slate-500 mb-1.5 block flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-sky-400" />
            Current Location
          </label>
          <select
            value={startNodeId ?? ''}
            onChange={(e) => setStartNodeId(e.target.value || null)}
            className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-sky-500 focus:outline-none"
          >
            <option value="">— Select location —</option>
            {nodes.map((n) => (
              <option key={n.id} value={n.id}>{n.label}</option>
            ))}
          </select>
        </div>
        <div className="rounded-xl bg-slate-800/50 border border-slate-700 p-4">
          <label className="text-xs text-slate-500 mb-1.5 block flex items-center gap-1.5">
            <Flag className="w-3.5 h-3.5 text-purple-400" />
            Target Exit
          </label>
          <select
            value={targetNodeId ?? ''}
            onChange={(e) => setTargetNodeId(e.target.value || null)}
            className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-purple-500 focus:outline-none"
          >
            <option value="">— Select exit —</option>
            {nodes
              .filter((n) => n.type === 'exit' || n.type === 'gate')
              .map((n) => (
                <option key={n.id} value={n.id}>{n.label}</option>
              ))}
          </select>
        </div>
      </div>

      {/* Map */}
      <CampusMap routePath={routePath} routeEdgeKeys={routeEdgeKeys} />

      {/* Route results */}
      {targetNodeId && primaryRoute ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Primary route */}
          <div className="lg:col-span-2 rounded-2xl bg-gradient-to-br from-green-600/10 to-emerald-600/5 border border-green-500/30 p-5">
            <div className="flex items-center gap-2 mb-4">
              <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-green-500/20">
                <Route className="w-5 h-5 text-green-400" />
              </div>
              <h2 className="text-sm font-bold text-white">Primary Escape Route</h2>
              <span className="ml-auto rounded-full bg-green-500/20 px-2.5 py-0.5 text-[11px] font-semibold text-green-300">
                SHORTEST
              </span>
            </div>
            <div className="grid grid-cols-3 gap-3 mb-4">
              <div className="rounded-lg bg-slate-900/60 border border-slate-700 p-3 text-center">
                <Ruler className="w-4 h-4 text-slate-400 mx-auto mb-1" />
                <p className="text-lg font-bold text-white">{primaryRoute.distance}m</p>
                <p className="text-[11px] text-slate-500">Distance</p>
              </div>
              <div className="rounded-lg bg-slate-900/60 border border-slate-700 p-3 text-center">
                <Clock className="w-4 h-4 text-slate-400 mx-auto mb-1" />
                <p className="text-lg font-bold text-white">{formatTime(primaryRoute.timeSeconds)}</p>
                <p className="text-[11px] text-slate-500">Est. Time</p>
              </div>
              <div className="rounded-lg bg-slate-900/60 border border-slate-700 p-3 text-center">
                <Footprints className="w-4 h-4 text-slate-400 mx-auto mb-1" />
                <p className="text-lg font-bold text-white">{primaryRoute.path.length}</p>
                <p className="text-[11px] text-slate-500">Waypoints</p>
              </div>
            </div>
            {/* Directions */}
            <div className="rounded-lg bg-slate-900/60 border border-slate-700 p-4">
              <h3 className="flex items-center gap-2 text-xs font-semibold text-slate-400 mb-3">
                <ListOrdered className="w-4 h-4" />
                Step-by-Step Directions
              </h3>
              <ol className="space-y-2">
                {primaryRoute.directions.map((dir, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm text-slate-300">
                    <span className="flex items-center justify-center w-6 h-6 rounded-full bg-green-500/20 text-green-300 text-xs font-bold shrink-0">
                      {i + 1}
                    </span>
                    {dir}
                  </li>
                ))}
              </ol>
            </div>
          </div>

          {/* Alternative route + route path */}
          <div className="space-y-4">
            {/* Path overview */}
            <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-5">
              <h3 className="text-sm font-bold text-white mb-3">Route Path</h3>
              <div className="flex flex-wrap gap-1.5">
                {primaryRoute.path.map((id, i) => (
                  <span key={id} className="flex items-center gap-1">
                    <span
                      className={`rounded px-2 py-0.5 text-[11px] font-medium ${
                        i === 0
                          ? 'bg-sky-500/20 text-sky-300'
                          : i === primaryRoute.path.length - 1
                          ? 'bg-purple-500/20 text-purple-300'
                          : 'bg-slate-700 text-slate-300'
                      }`}
                    >
                      {nodeMap.get(id)?.label ?? id}
                    </span>
                    {i < primaryRoute.path.length - 1 && (
                      <span className="text-slate-600 text-xs">→</span>
                    )}
                  </span>
                ))}
              </div>
            </div>

            {/* Alternative route */}
            {altRoute && altRoute.path.length > 1 ? (
              <div className="rounded-2xl bg-slate-800/50 border border-amber-500/30 p-5">
                <div className="flex items-center gap-2 mb-3">
                  <RotateCcw className="w-4 h-4 text-amber-400" />
                  <h3 className="text-sm font-bold text-white">Alternative Route</h3>
                </div>
                <p className="text-xs text-slate-400 mb-3">
                  If the primary route becomes blocked, this is the next best path.
                </p>
                <div className="grid grid-cols-2 gap-2 mb-3">
                  <div className="rounded-lg bg-slate-900/60 border border-slate-700 p-2 text-center">
                    <p className="text-sm font-bold text-white">{altRoute.distance}m</p>
                    <p className="text-[10px] text-slate-500">Distance</p>
                  </div>
                  <div className="rounded-lg bg-slate-900/60 border border-slate-700 p-2 text-center">
                    <p className="text-sm font-bold text-white">{formatTime(altRoute.timeSeconds)}</p>
                    <p className="text-[10px] text-slate-500">Est. Time</p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-1">
                  {altRoute.path.map((id, i) => (
                    <span key={id} className="text-[11px] text-slate-400">
                      {nodeMap.get(id)?.label}
                      {i < altRoute.path.length - 1 && ' → '}
                    </span>
                  ))}
                </div>
              </div>
            ) : (
              <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-5">
                <h3 className="text-sm font-bold text-white mb-2">Alternative Route</h3>
                <p className="text-xs text-slate-500">No alternative route available to this exit.</p>
              </div>
            )}
          </div>
        </div>
      ) : targetNodeId && !primaryRoute ? (
        <div className="rounded-2xl bg-red-500/10 border border-red-500/30 p-6 text-center">
          <AlertTriangle className="w-10 h-10 text-red-400 mx-auto mb-3" />
          <h2 className="text-lg font-bold text-white mb-2">No Safe Route Found</h2>
          <p className="text-sm text-slate-400 max-w-md mx-auto mb-4">
            All paths to this exit are blocked. Try a different exit or clear some blockages.
          </p>
          <button
            onClick={() => onNavigate('map')}
            className="rounded-lg bg-slate-800 border border-slate-700 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-700 transition-colors"
          >
            Return to Map
          </button>
        </div>
      ) : (
        <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-6 text-center">
          <Flag className="w-10 h-10 text-slate-500 mx-auto mb-3" />
          <p className="text-sm text-slate-400">
            Select a target exit above to compute your escape route, or use "Nearest Exit" for automatic detection.
          </p>
        </div>
      )}
    </div>
  );
}
