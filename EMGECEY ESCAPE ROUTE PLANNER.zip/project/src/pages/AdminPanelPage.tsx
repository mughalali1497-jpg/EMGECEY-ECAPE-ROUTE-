// ============================================================================
// AdminPanelPage — Manage campus graph: nodes, edges, blockages
// ----------------------------------------------------------------------------

import { useState } from 'react';
import {
  ShieldCheck,
  Plus,
  Trash2,
  Ban,
  MapPin,
  Link2,
  AlertTriangle,
  Building2,
  DoorOpen,
  Fence,
  Columns3,
  DoorClosed,
  LogIn,
  Split,
  Save,
  Siren,
  Users,
  CheckCircle2,
  Footprints,
  Power,
  FileText,
  Flag,
  Image as ImageIcon,
  X,
  Phone,
  Hash,
  User,
  Volume2,
  VolumeX,
  Play,
  Square,
  Map as MapIcon,
  MousePointerClick,
} from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { useEmergency, type StudentSafetyStatus, type ProblemReport, type ProblemPriority, type ReportStatus } from '@/context/EmergencyContext';
import { useVoice } from '@/context/VoiceContext';
import CampusMap from '@/components/CampusMap';
import type { NodeType } from '@/types';

const NODE_TYPE_OPTIONS: { value: NodeType; label: string; icon: typeof Building2 }[] = [
  { value: 'classroom', label: 'Classroom', icon: DoorClosed },
  { value: 'corridor', label: 'Corridor', icon: LogIn },
  { value: 'intersection', label: 'Intersection', icon: Split },
  { value: 'stairs', label: 'Stairs', icon: Columns3 },
  { value: 'building', label: 'Building', icon: Building2 },
  { value: 'exit', label: 'Emergency Exit', icon: DoorOpen },
  { value: 'gate', label: 'Gate', icon: Fence },
  { value: 'entrance', label: 'Entrance', icon: DoorOpen },
];

type Tab = 'emergency' | 'reports' | 'locations' | 'paths' | 'blockages' | 'students';

const EMERGENCY_TYPES = ['Fire', 'Earthquake', 'Gas Leak', 'Chemical Spill', 'Structural Damage', 'Other'];

const STUDENT_STATUS_CFG: Record<StudentSafetyStatus, { label: string; color: string; bg: string; border: string; icon: typeof ShieldCheck }> = {
  safe: { label: 'Safe', color: 'text-green-300', bg: 'bg-green-500/10', border: 'border-green-500/30', icon: CheckCircle2 },
  in_danger: { label: 'In Danger', color: 'text-red-300', bg: 'bg-red-500/10', border: 'border-red-500/30', icon: AlertTriangle },
  evacuating: { label: 'Evacuating', color: 'text-amber-300', bg: 'bg-amber-500/10', border: 'border-amber-500/30', icon: Footprints },
};

const PRIORITY_STYLE: Record<ProblemPriority, { color: string; bg: string; border: string }> = {
  Low: { color: 'text-green-300', bg: 'bg-green-500/10', border: 'border-green-500/30' },
  Medium: { color: 'text-sky-300', bg: 'bg-sky-500/10', border: 'border-sky-500/30' },
  High: { color: 'text-amber-300', bg: 'bg-amber-500/10', border: 'border-amber-500/30' },
  Critical: { color: 'text-red-300', bg: 'bg-red-500/10', border: 'border-red-500/30' },
};

const REPORT_STATUS_STYLE: Record<ReportStatus, { color: string; bg: string; border: string; label: string }> = {
  pending: { color: 'text-amber-300', bg: 'bg-amber-500/10', border: 'border-amber-500/30', label: 'Pending' },
  reviewed: { color: 'text-sky-300', bg: 'bg-sky-500/10', border: 'border-sky-500/30', label: 'Reviewed' },
  resolved: { color: 'text-green-300', bg: 'bg-green-500/10', border: 'border-green-500/30', label: 'Resolved' },
};

export default function AdminPanelPage() {
  const {
    nodes,
    edges,
    nodeMap,
    blockages,
    addNode,
    removeNode,
    addEdge,
    removeEdge,
    addBlockage,
    removeBlockage,
    clearBlockages,
    isNodeBlocked,
    isEdgeBlocked,
  } = useApp();

  const {
    emergencyState,
    studentStatuses,
    problemReports,
    activateEmergency,
    deactivateEmergency,
    deleteStudentStatus,
    updateProblemReportStatus,
    deleteProblemReport,
  } = useEmergency();

  const [tab, setTab] = useState<Tab>('emergency');

  // Emergency toggle form
  const [emgType, setEmgType] = useState('Fire');
  const [emgDesc, setEmgDesc] = useState('');
  const [emgVoiceMsg, setEmgVoiceMsg] = useState('');
  const [emgBusy, setEmgBusy] = useState(false);
  const [emgError, setEmgError] = useState<string | null>(null);

  // New node form
  const [newNodeLabel, setNewNodeLabel] = useState('');
  const [newNodeType, setNewNodeType] = useState<NodeType>('classroom');
  const [newNodeX, setNewNodeX] = useState(500);
  const [newNodeY, setNewNodeY] = useState(320);
  const [newNodeDesc, setNewNodeDesc] = useState('');

  // New edge form
  const [edgeSource, setEdgeSource] = useState('');
  const [edgeTarget, setEdgeTarget] = useState('');
  const [edgeDistance, setEdgeDistance] = useState(30);

  // New blockage form
  const [blockKind, setBlockKind] = useState<'node' | 'edge'>('node');
  const [blockRefId, setBlockRefId] = useState('');
  const [blockReason, setBlockReason] = useState('');

  // Report review modal state
  const [viewingReport, setViewingReport] = useState<ProblemReport | null>(null);
  const [reportStatus, setReportStatus] = useState<ReportStatus>('pending');
  const [reportAdminNotes, setReportAdminNotes] = useState('');
  const [reportBusy, setReportBusy] = useState(false);
  const [reportMsg, setReportMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [reportDeletingId, setReportDeletingId] = useState<string | null>(null);

  // Interactive map blocking state
  const [blockMode, setBlockMode] = useState(false);
  const [blockFeedback, setBlockFeedback] = useState<string | null>(null);

  const { voicePlaying, startVoice, stopVoice } = useVoice();

  const announcementText = emergencyState?.is_active
    ? `Attention. This is an emergency alert. ${emergencyState.emergency_type || 'Emergency'} emergency has been declared on campus. ${emergencyState.description || ''} Please evacuate immediately using the nearest exit. Do not use elevators. Stay calm and follow the evacuation routes on the campus map.`
      + (emergencyState.voice_message?.trim() ? ` ${emergencyState.voice_message.trim()}` : '')
    : '';

  const handleAddNode = () => {
    if (!newNodeLabel.trim()) return;
    addNode({
      label: newNodeLabel.trim(),
      type: newNodeType,
      x: newNodeX,
      y: newNodeY,
      description: newNodeDesc.trim() || undefined,
    });
    setNewNodeLabel('');
    setNewNodeDesc('');
  };

  const handleAddEdge = () => {
    if (!edgeSource || !edgeTarget || edgeSource === edgeTarget) return;
    addEdge({
      source: edgeSource,
      target: edgeTarget,
      distance: Math.max(1, edgeDistance),
    });
    setEdgeSource('');
    setEdgeTarget('');
    setEdgeDistance(30);
  };

  const handleAddBlockage = () => {
    if (!blockRefId) return;
    addBlockage({
      kind: blockKind,
      refId: blockRefId,
      reason: blockReason.trim() || 'Hazardous area',
    });
    setBlockRefId('');
    setBlockReason('');
  };

  const studentCounts = {
    safe: studentStatuses.filter((s) => s.status === 'safe').length,
    in_danger: studentStatuses.filter((s) => s.status === 'in_danger').length,
    evacuating: studentStatuses.filter((s) => s.status === 'evacuating').length,
  };

  const handleActivate = async () => {
    setEmgBusy(true);
    setEmgError(null);
    try {
      await activateEmergency(
        emgType,
        emgDesc.trim() || `${emgType} emergency declared on campus`,
        emgVoiceMsg.trim() || undefined,
      );
      setEmgVoiceMsg('');
    } catch (e) {
      setEmgError((e as Error).message);
    }
    setEmgBusy(false);
  };

  const handleDeactivate = async () => {
    setEmgBusy(true);
    setEmgError(null);
    try {
      await deactivateEmergency();
    } catch (e) {
      setEmgError((e as Error).message);
    }
    setEmgBusy(false);
  };

  const handleMapNodeClick = (nodeId: string) => {
    if (!blockMode) return;
    if (isNodeBlocked(nodeId)) {
      const blockage = blockages.find((b) => b.kind === 'node' && b.refId === nodeId);
      if (blockage) removeBlockage(blockage.id);
      setBlockFeedback(`Unblocked: ${nodeMap.get(nodeId)?.label}`);
    } else {
      addBlockage({ kind: 'node', refId: nodeId, reason: 'Admin-blocked during emergency' });
      setBlockFeedback(`Blocked: ${nodeMap.get(nodeId)?.label}`);
    }
  };

  const handleReportSave = async () => {
    if (!viewingReport) return;
    setReportBusy(true);
    setReportMsg(null);
    const result = await updateProblemReportStatus(viewingReport.id, reportStatus, reportAdminNotes.trim());
    setReportBusy(false);
    if (result.success) {
      setReportMsg({ ok: true, text: 'Report status updated.' });
      setViewingReport(null);
    } else {
      setReportMsg({ ok: false, text: result.error ?? 'Failed to update report.' });
    }
  };

  const handleReportDelete = async (id: string) => {
    try {
      await deleteProblemReport(id);
      setReportDeletingId(null);
      if (viewingReport?.id === id) setViewingReport(null);
    } catch {
      setReportMsg({ ok: false, text: 'Failed to delete report.' });
    }
  };

  const openReportModal = (r: ProblemReport) => {
    setViewingReport(r);
    setReportStatus(r.status);
    setReportAdminNotes(r.admin_notes);
    setReportMsg(null);
  };

  const reportCounts = {
    pending: problemReports.filter((r) => r.status === 'pending').length,
    reviewed: problemReports.filter((r) => r.status === 'reviewed').length,
    resolved: problemReports.filter((r) => r.status === 'resolved').length,
    critical: problemReports.filter((r) => r.priority === 'Critical').length,
  };

  const tabs: { id: Tab; label: string; icon: typeof MapPin; count: number }[] = [
    { id: 'emergency', label: 'Emergency', icon: Siren, count: emergencyState?.is_active ? 1 : 0 },
    { id: 'reports', label: 'Reports', icon: FileText, count: problemReports.length },
    { id: 'students', label: 'Students', icon: Users, count: studentStatuses.length },
    { id: 'locations', label: 'Locations', icon: MapPin, count: nodes.length },
    { id: 'paths', label: 'Paths', icon: Link2, count: edges.length },
    { id: 'blockages', label: 'Blockages', icon: Ban, count: blockages.length },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-slate-600 to-slate-700 border border-slate-600">
          <ShieldCheck className="w-5 h-5 text-slate-300" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-white">Admin Panel</h1>
          <p className="text-sm text-slate-400">Manage campus map data, paths, and blockages</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-xl bg-slate-800/50 border border-slate-700 p-4">
          <div className="flex items-center gap-2 mb-1">
            <MapPin className="w-4 h-4 text-sky-400" />
            <span className="text-xs text-slate-500">Locations</span>
          </div>
          <p className="text-2xl font-bold text-white">{nodes.length}</p>
        </div>
        <div className="rounded-xl bg-slate-800/50 border border-slate-700 p-4">
          <div className="flex items-center gap-2 mb-1">
            <Link2 className="w-4 h-4 text-amber-400" />
            <span className="text-xs text-slate-500">Paths</span>
          </div>
          <p className="text-2xl font-bold text-white">{edges.length}</p>
        </div>
        <div className="rounded-xl bg-slate-800/50 border border-slate-700 p-4">
          <div className="flex items-center gap-2 mb-1">
            <Ban className="w-4 h-4 text-red-400" />
            <span className="text-xs text-slate-500">Blockages</span>
          </div>
          <p className="text-2xl font-bold text-white">{blockages.length}</p>
        </div>
      </div>

      {/* Tab selector */}
      <div className="flex gap-2 border-b border-slate-700">
        {tabs.map((t) => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors ${
                active
                  ? 'border-red-500 text-white'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className="w-4 h-4" />
              {t.label}
              <span className="rounded-full bg-slate-700 px-2 py-0.5 text-[11px] text-slate-300">
                {t.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* EMERGENCY TAB */}
      {tab === 'emergency' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Emergency control */}
          <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-5">
            <h3 className="flex items-center gap-2 text-sm font-bold text-white mb-4">
              <Siren className="w-4 h-4 text-red-400" />
              Emergency Declaration
            </h3>

            {/* Current state */}
            <div
              className={`rounded-xl border p-4 mb-4 ${
                emergencyState?.is_active
                  ? 'bg-red-500/10 border-red-500/30'
                  : 'bg-green-500/10 border-green-500/30'
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`flex items-center justify-center w-10 h-10 rounded-lg ${
                    emergencyState?.is_active
                      ? 'bg-red-500/20'
                      : 'bg-green-500/20'
                  }`}
                >
                  {emergencyState?.is_active ? (
                    <Siren className="w-5 h-5 text-red-400 animate-pulse" />
                  ) : (
                    <ShieldCheck className="w-5 h-5 text-green-400" />
                  )}
                </div>
                <div>
                  <p className="text-sm font-bold text-white">
                    {emergencyState?.is_active ? 'EMERGENCY ACTIVE' : 'No Active Emergency'}
                  </p>
                  {emergencyState?.is_active && (
                    <p className="text-xs text-red-300">
                      {emergencyState.emergency_type} — {emergencyState.description}
                    </p>
                  )}
                  {emergencyState?.activated_at && (
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Activated: {new Date(emergencyState.activated_at).toLocaleString()}
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Activate form (only when inactive) */}
            {!emergencyState?.is_active ? (
              <div className="space-y-3">
                <div>
                  <label className="text-xs text-slate-500 mb-1 block">Emergency Type</label>
                  <select
                    value={emgType}
                    onChange={(e) => setEmgType(e.target.value)}
                    className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-red-500 focus:outline-none"
                  >
                    {EMERGENCY_TYPES.map((t) => (
                      <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-slate-500 mb-1 block">Description</label>
                  <textarea
                    value={emgDesc}
                    onChange={(e) => setEmgDesc(e.target.value)}
                    placeholder="Describe the emergency situation..."
                    rows={3}
                    className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-red-500 focus:outline-none resize-none"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500 mb-1 flex items-center gap-1.5">
                    <Volume2 className="w-3.5 h-3.5 text-amber-400" />
                    Custom Voice Message <span className="text-slate-600 font-normal">(optional)</span>
                  </label>
                  <textarea
                    value={emgVoiceMsg}
                    onChange={(e) => setEmgVoiceMsg(e.target.value)}
                    placeholder="Type a message in your own words to be spoken aloud after the standard announcement. Leave blank to use only the predefined message."
                    rows={2}
                    className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none resize-none"
                  />
                  <p className="text-[11px] text-slate-600 mt-1">
                    This is appended to the predefined announcement — the standard message is always spoken.
                  </p>
                </div>
                {emgError && (
                  <p className="rounded-lg bg-red-500/10 border border-red-500/30 px-3 py-2 text-sm text-red-300">
                    {emgError}
                  </p>
                )}
                <button
                  onClick={handleActivate}
                  disabled={emgBusy}
                  className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-red-500 to-orange-500 px-4 py-2.5 text-sm font-semibold text-white hover:scale-[1.01] transition-transform disabled:opacity-40"
                >
                  <Power className="w-4 h-4" />
                  {emgBusy ? 'Activating...' : 'Declare Emergency'}
                </button>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Declaring an emergency unlocks the Student Panel, allowing students
                  to check in their safety status and access the campus evacuation map.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {emgError && (
                  <p className="rounded-lg bg-red-500/10 border border-red-500/30 px-3 py-2 text-sm text-red-300">
                    {emgError}
                  </p>
                )}
                <button
                  onClick={handleDeactivate}
                  disabled={emgBusy}
                  className="flex items-center gap-2 rounded-lg bg-green-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-green-500 transition-colors disabled:opacity-40"
                >
                  <Power className="w-4 h-4" />
                  {emgBusy ? 'Deactivating...' : 'End Emergency'}
                </button>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Ending the emergency locks the Student Panel. Student check-in data
                  is preserved for review in the Students tab.
                </p>
              </div>
            )}
          </div>

          {/* Student status summary */}
          <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-5">
            <h3 className="flex items-center gap-2 text-sm font-bold text-white mb-4">
              <Users className="w-4 h-4 text-sky-400" />
              Student Safety Summary
            </h3>
            <div className="grid grid-cols-3 gap-3 mb-4">
              <div className="rounded-xl bg-green-500/10 border border-green-500/30 p-4 text-center">
                <CheckCircle2 className="w-5 h-5 text-green-400 mx-auto mb-1.5" />
                <p className="text-2xl font-bold text-white">{studentCounts.safe}</p>
                <p className="text-xs text-slate-500">Safe</p>
              </div>
              <div className="rounded-xl bg-amber-500/10 border border-amber-500/30 p-4 text-center">
                <Footprints className="w-5 h-5 text-amber-400 mx-auto mb-1.5" />
                <p className="text-2xl font-bold text-white">{studentCounts.evacuating}</p>
                <p className="text-xs text-slate-500">Evacuating</p>
              </div>
              <div className="rounded-xl bg-red-500/10 border border-red-500/30 p-4 text-center">
                <AlertTriangle className="w-5 h-5 text-red-400 mx-auto mb-1.5" />
                <p className="text-2xl font-bold text-white">{studentCounts.in_danger}</p>
                <p className="text-xs text-slate-500">In Danger</p>
              </div>
            </div>
            <div className="rounded-lg bg-slate-900/60 border border-slate-700 p-3 text-center">
              <p className="text-3xl font-bold text-white">{studentStatuses.length}</p>
              <p className="text-xs text-slate-500 mt-1">Total Check-ins</p>
            </div>
          </div>
        </div>

          {/* Voice announcement controls */}
          {emergencyState?.is_active && (
            <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-5">
              <h3 className="flex items-center gap-2 text-sm font-bold text-white mb-4">
                <Volume2 className="w-4 h-4 text-amber-400" />
                Voice Emergency Announcement
              </h3>
              <div className="rounded-lg bg-amber-500/10 border border-amber-500/30 p-3 mb-4">
                <p className="text-xs text-amber-300 leading-relaxed">
                  "{announcementText}"
                </p>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={startVoice}
                  disabled={voicePlaying}
                  className="flex items-center gap-2 rounded-lg bg-amber-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-amber-500 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <Play className="w-4 h-4" />
                  Start Announcement
                </button>
                <button
                  onClick={stopVoice}
                  disabled={!voicePlaying}
                  className="flex items-center gap-2 rounded-lg bg-slate-700 px-5 py-2.5 text-sm font-semibold text-slate-300 hover:bg-slate-600 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <Square className="w-4 h-4" />
                  Stop Announcement
                </button>
                {voicePlaying && (
                  <span className="flex items-center gap-2 text-xs text-amber-300">
                    <Volume2 className="w-4 h-4 animate-pulse" />
                    Announcement playing in loop...
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 mt-3 leading-relaxed">
                The announcement auto-plays when an emergency is declared and loops until
                stopped. Use these controls to start or stop the voice at any time.
              </p>
            </div>
          )}

          {/* Interactive path blocking on map */}
          {emergencyState?.is_active && (
            <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="flex items-center gap-2 text-sm font-bold text-white">
                  <MapIcon className="w-4 h-4 text-red-400" />
                  Block / Unblock Paths on Campus Map
                </h3>
                <button
                  onClick={() => setBlockMode((v) => !v)}
                  className={`flex items-center gap-2 rounded-lg px-4 py-1.5 text-xs font-semibold transition-colors ${
                    blockMode
                      ? 'bg-red-600 text-white hover:bg-red-500'
                      : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                  }`}
                >
                  <Ban className="w-3.5 h-3.5" />
                  {blockMode ? 'Block Mode ON' : 'Enable Block Mode'}
                </button>
              </div>
              {blockMode && (
                <div className="flex items-center gap-2 rounded-lg bg-red-500/10 border border-red-500/30 px-3 py-2 text-xs text-red-300 mb-3">
                  <MousePointerClick className="w-3.5 h-3.5" />
                  Click any node on the map to block or unblock it. Blocked nodes turn red and are excluded from escape routes.
                </div>
              )}
              {blockFeedback && (
                <div className="rounded-lg bg-sky-500/10 border border-sky-500/30 px-3 py-2 text-xs text-sky-300 mb-3">
                  {blockFeedback}
                </div>
              )}
              <CampusMap
                onSelectNode={handleMapNodeClick}
                selectionMode={blockMode ? 'block' : null}
              />
              {/* Active blockages list */}
              {blockages.length > 0 && (
                <div className="mt-4">
                  <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">
                    Active Blockages ({blockages.length})
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {blockages.map((b) => {
                      const label =
                        b.kind === 'node'
                          ? nodeMap.get(b.refId)?.label ?? b.refId
                          : `Path ${b.refId}`;
                      return (
                        <span
                          key={b.id}
                          className="flex items-center gap-2 rounded-lg bg-red-500/10 border border-red-500/20 px-3 py-1.5 text-xs text-red-300"
                        >
                          <Ban className="w-3 h-3" />
                          {label}
                          <button
                            onClick={() => removeBlockage(b.id)}
                            className="ml-1 text-red-400 hover:text-red-200"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </span>
                      );
                    })}
                  </div>
                  {blockages.length > 1 && (
                    <button
                      onClick={clearBlockages}
                      className="mt-2 text-xs text-slate-400 hover:text-red-400 transition-colors"
                    >
                      Clear all blockages
                    </button>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* REPORTS TAB */}
      {tab === 'reports' && (
        <div className="space-y-4">
          {/* Report summary stats */}
          <div className="grid grid-cols-4 gap-3">
            <div className="rounded-xl bg-amber-500/10 border border-amber-500/30 p-4 text-center">
              <p className="text-2xl font-bold text-white">{reportCounts.pending}</p>
              <p className="text-xs text-slate-500">Pending</p>
            </div>
            <div className="rounded-xl bg-sky-500/10 border border-sky-500/30 p-4 text-center">
              <p className="text-2xl font-bold text-white">{reportCounts.reviewed}</p>
              <p className="text-xs text-slate-500">Reviewed</p>
            </div>
            <div className="rounded-xl bg-green-500/10 border border-green-500/30 p-4 text-center">
              <p className="text-2xl font-bold text-white">{reportCounts.resolved}</p>
              <p className="text-xs text-slate-500">Resolved</p>
            </div>
            <div className="rounded-xl bg-red-500/10 border border-red-500/30 p-4 text-center">
              <p className="text-2xl font-bold text-white">{reportCounts.critical}</p>
              <p className="text-xs text-slate-500">Critical</p>
            </div>
          </div>

          {/* Reports list */}
          <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-5">
            <h3 className="text-sm font-bold text-white mb-4">
              Student Problem Reports ({problemReports.length})
            </h3>
            {problemReports.length === 0 ? (
              <div className="text-center py-10">
                <FileText className="w-10 h-10 text-slate-600 mx-auto mb-3" />
                <p className="text-sm text-slate-400">
                  No problem reports submitted yet. Reports from students will appear here
                  when they file a safety problem from the Student Panel.
                </p>
              </div>
            ) : (
              <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
                {problemReports.map((r) => {
                  const pStyle = PRIORITY_STYLE[r.priority];
                  const sStyle = REPORT_STATUS_STYLE[r.status];
                  return (
                    <div
                      key={r.id}
                      className="rounded-lg bg-slate-900/40 border border-slate-700/50 px-3 py-3"
                    >
                      <div className="flex items-start gap-3">
                        <div className={`flex items-center justify-center w-8 h-8 rounded-lg ${pStyle.bg} ${pStyle.border} border shrink-0`}>
                          <Flag className={`w-4 h-4 ${pStyle.color}`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="text-sm font-semibold text-white">{r.problem_type}</p>
                            <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${pStyle.bg} ${pStyle.color} border ${pStyle.border}`}>
                              {r.priority}
                            </span>
                            <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${sStyle.bg} ${sStyle.color} border ${sStyle.border}`}>
                              {sStyle.label}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500 mt-0.5">
                            {r.building_block && `${r.building_block} · `}
                            {r.floor && `${r.floor} · `}
                            {r.room_area}
                            {r.map_node_id && ` · ${nodeMap.get(r.map_node_id)?.label ?? r.map_node_id}`}
                          </p>
                          {r.description && (
                            <p className="text-xs text-slate-400 mt-1 line-clamp-2">{r.description}</p>
                          )}
                          {r.photo_url && (
                            <img src={r.photo_url} alt="Report" className="mt-2 rounded-lg max-h-24 object-cover" />
                          )}
                          <p className="text-[10px] text-slate-600 mt-1">
                            By {r.student_name}
                            {r.student_roll_number && ` (${r.student_roll_number})`}
                            {r.student_mobile && ` · ${r.student_mobile}`}
                            {' — '}
                            {new Date(r.created_at).toLocaleString()}
                          </p>
                        </div>
                        <div className="flex flex-col gap-1 shrink-0">
                          <button
                            onClick={() => openReportModal(r)}
                            className="flex items-center justify-center w-7 h-7 rounded-lg text-slate-400 hover:text-sky-400 hover:bg-sky-500/10 transition-colors"
                            title="Review report"
                          >
                            <FileText className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setReportDeletingId(r.id)}
                            className="flex items-center justify-center w-7 h-7 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                            title="Delete report"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* REPORT REVIEW MODAL */}
      {viewingReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setViewingReport(null)}
          />
          <div className="relative w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-700 px-5 py-3 sticky top-0 bg-slate-900 z-10">
              <h3 className="flex items-center gap-2 text-sm font-bold text-white">
                <FileText className="w-4 h-4 text-amber-400" />
                Review Report
              </h3>
              <button
                onClick={() => setViewingReport(null)}
                className="text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 space-y-3">
              {(() => {
                const r = viewingReport;
                const pStyle = PRIORITY_STYLE[r.priority];
                const sStyle = REPORT_STATUS_STYLE[r.status];
                return (
                  <>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`rounded-full px-3 py-1 text-xs font-bold ${pStyle.bg} ${pStyle.color} border ${pStyle.border}`}>
                        {r.priority} Priority
                      </span>
                      <span className={`rounded-full px-3 py-1 text-xs font-bold ${sStyle.bg} ${sStyle.color} border ${sStyle.border}`}>
                        {sStyle.label}
                      </span>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 mb-0.5">Problem Type</p>
                      <p className="text-sm font-bold text-white">{r.problem_type}</p>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <p className="text-xs text-slate-500 mb-0.5">Building / Block</p>
                        <p className="text-sm text-slate-200">{r.building_block || '—'}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 mb-0.5">Floor</p>
                        <p className="text-sm text-slate-200">{r.floor || '—'}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 mb-0.5">Room / Area</p>
                        <p className="text-sm text-slate-200">{r.room_area || '—'}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 mb-0.5">Map Location</p>
                        <p className="text-sm text-slate-200">
                          {r.map_node_id ? nodeMap.get(r.map_node_id)?.label ?? r.map_node_id : '—'}
                        </p>
                      </div>
                    </div>
                    {r.description && (
                      <div>
                        <p className="text-xs text-slate-500 mb-0.5">Description</p>
                        <p className="text-sm text-slate-300 leading-relaxed rounded-lg bg-slate-800/50 border border-slate-700 p-3">
                          {r.description}
                        </p>
                      </div>
                    )}
                    {r.photo_url && (
                      <div>
                        <p className="text-xs text-slate-500 mb-1 flex items-center gap-1">
                          <ImageIcon className="w-3 h-3" /> Attached Photo
                        </p>
                        <img src={r.photo_url} alt="Report" className="rounded-lg w-full max-h-64 object-cover" />
                      </div>
                    )}
                    <div className="rounded-lg bg-slate-800/50 border border-slate-700 p-3">
                      <p className="text-xs text-slate-500 mb-1">Reported By</p>
                      <p className="text-sm font-semibold text-white">{r.student_name}</p>
                      <p className="text-[11px] text-slate-500">
                        {r.student_roll_number && `Roll: ${r.student_roll_number} · `}
                        {r.student_mobile && `Mobile: ${r.student_mobile}`}
                      </p>
                      <p className="text-[10px] text-slate-600 mt-0.5">
                        {new Date(r.created_at).toLocaleString()}
                      </p>
                    </div>

                    {/* Admin controls */}
                    <div className="border-t border-slate-700 pt-3 space-y-3">
                      <div>
                        <label className="text-xs text-slate-500 mb-1.5 block">Update Status</label>
                        <div className="grid grid-cols-3 gap-2">
                          {(['pending', 'reviewed', 'resolved'] as ReportStatus[]).map((st) => {
                            const cfg = REPORT_STATUS_STYLE[st];
                            const active = reportStatus === st;
                            return (
                              <button
                                key={st}
                                onClick={() => setReportStatus(st)}
                                className={`rounded-lg border px-3 py-2 text-sm font-semibold transition-all ${
                                  active
                                    ? `${cfg.bg} ${cfg.border} ${cfg.color}`
                                    : 'border-slate-700 text-slate-400 hover:border-slate-600'
                                }`}
                              >
                                {cfg.label}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                      <div>
                        <label className="text-xs text-slate-500 mb-1 block">Admin Notes</label>
                        <textarea
                          value={reportAdminNotes}
                          onChange={(e) => setReportAdminNotes(e.target.value)}
                          placeholder="Add notes about this report..."
                          rows={3}
                          className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-sky-500 focus:outline-none resize-none"
                        />
                      </div>
                      {reportMsg && (
                        <div
                          className={`rounded-lg px-3 py-2 text-sm ${
                            reportMsg.ok
                              ? 'bg-green-500/10 border border-green-500/30 text-green-300'
                              : 'bg-red-500/10 border border-red-500/30 text-red-300'
                          }`}
                        >
                          {reportMsg.text}
                        </div>
                      )}
                      <div className="flex gap-2">
                        <button
                          onClick={handleReportSave}
                          disabled={reportBusy}
                          className="flex-1 flex items-center justify-center gap-2 rounded-lg bg-sky-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-sky-500 transition-colors disabled:opacity-40"
                        >
                          {reportBusy ? 'Saving...' : 'Save Status'}
                          <FileText className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setReportDeletingId(r.id)}
                          className="rounded-lg bg-red-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-red-500 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setViewingReport(null)}
                          className="rounded-lg bg-slate-700 px-4 py-2.5 text-sm font-semibold text-slate-300 hover:bg-slate-600 transition-colors"
                        >
                          Close
                        </button>
                      </div>
                    </div>
                  </>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* REPORT DELETE CONFIRMATION */}
      {reportDeletingId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setReportDeletingId(null)}
          />
          <div className="relative w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl">
            <div className="p-5 text-center">
              <div className="flex items-center justify-center w-14 h-14 rounded-xl bg-red-500/15 border border-red-500/30 mx-auto mb-4">
                <Trash2 className="w-7 h-7 text-red-400" />
              </div>
              <h3 className="text-sm font-bold text-white mb-2">Delete This Report?</h3>
              <p className="text-xs text-slate-400 mb-5">
                This will permanently remove the safety problem report. This action cannot be undone.
              </p>
              <div className="flex gap-2">
                <button
                  onClick={() => handleReportDelete(reportDeletingId)}
                  className="flex-1 flex items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-red-500 transition-colors"
                >
                  Yes, Delete
                  <Trash2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setReportDeletingId(null)}
                  className="rounded-lg bg-slate-700 px-4 py-2.5 text-sm font-semibold text-slate-300 hover:bg-slate-600 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* STUDENTS TAB */}
      {tab === 'students' && (
        <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-white">
              Student Check-ins ({studentStatuses.length})
            </h3>
            {studentStatuses.length > 0 && (
              <div className="flex gap-3 text-xs">
                <span className="flex items-center gap-1 text-green-300">
                  <CheckCircle2 className="w-3 h-3" /> {studentCounts.safe} Safe
                </span>
                <span className="flex items-center gap-1 text-amber-300">
                  <Footprints className="w-3 h-3" /> {studentCounts.evacuating} Evacuating
                </span>
                <span className="flex items-center gap-1 text-red-300">
                  <AlertTriangle className="w-3 h-3" /> {studentCounts.in_danger} In Danger
                </span>
              </div>
            )}
          </div>
          {studentStatuses.length === 0 ? (
            <div className="text-center py-10">
              <Users className="w-10 h-10 text-slate-600 mx-auto mb-3" />
              <p className="text-sm text-slate-400">
                No student check-ins yet. Check-ins appear here when students
                submit their safety status during an active emergency.
              </p>
            </div>
          ) : (
            <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
              {studentStatuses.map((s) => {
                const cfg = STUDENT_STATUS_CFG[s.status];
                const Icon = cfg.icon;
                return (
                  <div
                    key={s.id}
                    className={`flex items-center gap-3 rounded-lg border px-3 py-2.5 ${cfg.bg} ${cfg.border}`}
                  >
                    <div className={`flex items-center justify-center w-8 h-8 rounded-lg ${cfg.bg} border ${cfg.border}`}>
                      <Icon className={`w-4 h-4 ${cfg.color}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-white truncate">
                        {s.student_name}
                        {s.student_id_number && (
                          <span className="text-slate-500 font-normal ml-1.5">({s.student_id_number})</span>
                        )}
                      </p>
                      <p className="text-[11px] text-slate-500 truncate">
                        {s.location ? nodeMap.get(s.location)?.label ?? s.location : 'No location'}
                        {s.notes && ` · ${s.notes}`}
                      </p>
                      <p className="text-[10px] text-slate-600 mt-0.5">
                        {new Date(s.created_at).toLocaleString()}
                      </p>
                    </div>
                    <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${cfg.bg} ${cfg.color} border ${cfg.border} shrink-0`}>
                      {cfg.label}
                    </span>
                    <button
                      onClick={() => deleteStudentStatus(s.id)}
                      className="text-slate-500 hover:text-red-400 transition-colors shrink-0"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* LOCATIONS TAB */}
      {tab === 'locations' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Add new location */}
          <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-5">
            <h3 className="flex items-center gap-2 text-sm font-bold text-white mb-4">
              <Plus className="w-4 h-4 text-green-400" />
              Add New Location
            </h3>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-500 mb-1 block">Name</label>
                <input
                  type="text"
                  value={newNodeLabel}
                  onChange={(e) => setNewNodeLabel(e.target.value)}
                  placeholder="e.g. Seminar Hall 3"
                  className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-green-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">Type</label>
                <div className="grid grid-cols-4 gap-2">
                  {NODE_TYPE_OPTIONS.map((opt) => {
                    const Icon = opt.icon;
                    const active = newNodeType === opt.value;
                    return (
                      <button
                        key={opt.value}
                        onClick={() => setNewNodeType(opt.value)}
                        className={`flex flex-col items-center gap-1 rounded-lg border p-2 text-[10px] font-medium transition-colors ${
                          active
                            ? 'border-green-500/50 bg-green-500/10 text-green-300'
                            : 'border-slate-700 text-slate-400 hover:border-slate-600'
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                        {opt.label}
                      </button>
                    );
                  })}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-500 mb-1 block">X coordinate (0–1000)</label>
                  <input
                    type="number"
                    min="0"
                    max="1000"
                    value={newNodeX}
                    onChange={(e) => setNewNodeX(Number(e.target.value))}
                    className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-green-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500 mb-1 block">Y coordinate (0–640)</label>
                  <input
                    type="number"
                    min="0"
                    max="640"
                    value={newNodeY}
                    onChange={(e) => setNewNodeY(Number(e.target.value))}
                    className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-green-500 focus:outline-none"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">Description (optional)</label>
                <input
                  type="text"
                  value={newNodeDesc}
                  onChange={(e) => setNewNodeDesc(e.target.value)}
                  placeholder="Short description"
                  className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-green-500 focus:outline-none"
                />
              </div>
              <button
                onClick={handleAddNode}
                disabled={!newNodeLabel.trim()}
                className="flex items-center gap-2 rounded-lg bg-green-600 px-4 py-2 text-sm font-semibold text-white hover:bg-green-500 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <Save className="w-4 h-4" />
                Add Location
              </button>
            </div>
          </div>

          {/* Existing locations */}
          <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-5">
            <h3 className="text-sm font-bold text-white mb-4">Existing Locations ({nodes.length})</h3>
            <div className="space-y-1.5 max-h-[420px] overflow-y-auto pr-1">
              {nodes.map((n) => {
                const blocked = isNodeBlocked(n.id);
                return (
                  <div
                    key={n.id}
                    className="flex items-center gap-3 rounded-lg bg-slate-900/40 border border-slate-700/50 px-3 py-2"
                  >
                    <span
                      className={`w-2 h-2 rounded-full shrink-0 ${
                        blocked ? 'bg-red-500' : 'bg-sky-500'
                      }`}
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-white truncate">{n.label}</p>
                      <p className="text-[11px] text-slate-500">
                        {n.type} · ({n.x}, {n.y})
                      </p>
                    </div>
                    {blocked && (
                      <span className="rounded bg-red-500/20 px-1.5 py-0.5 text-[10px] text-red-300">
                        blocked
                      </span>
                    )}
                    <button
                      onClick={() => removeNode(n.id)}
                      className="text-slate-500 hover:text-red-400 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* PATHS TAB */}
      {tab === 'paths' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Add new path */}
          <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-5">
            <h3 className="flex items-center gap-2 text-sm font-bold text-white mb-4">
              <Plus className="w-4 h-4 text-amber-400" />
              Add New Path
            </h3>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-500 mb-1 block">From (source)</label>
                <select
                  value={edgeSource}
                  onChange={(e) => setEdgeSource(e.target.value)}
                  className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
                >
                  <option value="">— Select location —</option>
                  {nodes.map((n) => (
                    <option key={n.id} value={n.id}>{n.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">To (target)</label>
                <select
                  value={edgeTarget}
                  onChange={(e) => setEdgeTarget(e.target.value)}
                  className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
                >
                  <option value="">— Select location —</option>
                  {nodes.map((n) => (
                    <option key={n.id} value={n.id}>{n.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">Distance (metres)</label>
                <input
                  type="number"
                  min="1"
                  value={edgeDistance}
                  onChange={(e) => setEdgeDistance(Number(e.target.value))}
                  className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
                />
              </div>
              <button
                onClick={handleAddEdge}
                disabled={!edgeSource || !edgeTarget || edgeSource === edgeTarget}
                className="flex items-center gap-2 rounded-lg bg-amber-600 px-4 py-2 text-sm font-semibold text-white hover:bg-amber-500 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <Save className="w-4 h-4" />
                Add Path
              </button>
            </div>
          </div>

          {/* Existing paths */}
          <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-5">
            <h3 className="text-sm font-bold text-white mb-4">Existing Paths ({edges.length})</h3>
            <div className="space-y-1.5 max-h-[420px] overflow-y-auto pr-1">
              {edges.map((e) => {
                const blocked = isEdgeBlocked(e.id);
                const s = nodeMap.get(e.source)?.label ?? e.source;
                const t = nodeMap.get(e.target)?.label ?? e.target;
                return (
                  <div
                    key={e.id}
                    className="flex items-center gap-3 rounded-lg bg-slate-900/40 border border-slate-700/50 px-3 py-2"
                  >
                    <span className={`w-2 h-2 rounded-full shrink-0 ${blocked ? 'bg-red-500' : 'bg-amber-500'}`} />
                    <div className="flex-1 min-w-0 text-sm text-slate-300">
                      <span className="text-white font-medium">{s}</span>
                      <span className="text-slate-500"> ↔ </span>
                      <span className="text-white font-medium">{t}</span>
                      <span className="text-slate-500 ml-2 text-[11px]">({e.distance}m)</span>
                    </div>
                    {blocked && (
                      <span className="rounded bg-red-500/20 px-1.5 py-0.5 text-[10px] text-red-300">
                        blocked
                      </span>
                    )}
                    <button
                      onClick={() => removeEdge(e.id)}
                      className="text-slate-500 hover:text-red-400 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* BLOCKAGES TAB */}
      {tab === 'blockages' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Add blockage */}
          <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-5">
            <h3 className="flex items-center gap-2 text-sm font-bold text-white mb-4">
              <AlertTriangle className="w-4 h-4 text-red-400" />
              Mark Area as Blocked / Dangerous
            </h3>
            <div className="space-y-3">
              <div className="flex gap-2">
                <button
                  onClick={() => setBlockKind('node')}
                  className={`flex-1 rounded-lg border px-3 py-2 text-sm font-semibold transition-colors ${
                    blockKind === 'node'
                      ? 'border-red-500/50 bg-red-500/10 text-red-300'
                      : 'border-slate-700 text-slate-400'
                  }`}
                >
                  Location
                </button>
                <button
                  onClick={() => setBlockKind('edge')}
                  className={`flex-1 rounded-lg border px-3 py-2 text-sm font-semibold transition-colors ${
                    blockKind === 'edge'
                      ? 'border-red-500/50 bg-red-500/10 text-red-300'
                      : 'border-slate-700 text-slate-400'
                  }`}
                >
                  Path
                </button>
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">
                  {blockKind === 'node' ? 'Select Location' : 'Select Path'}
                </label>
                <select
                  value={blockRefId}
                  onChange={(e) => setBlockRefId(e.target.value)}
                  className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-red-500 focus:outline-none"
                >
                  <option value="">— Select —</option>
                  {blockKind === 'node'
                    ? nodes.map((n) => (
                        <option key={n.id} value={n.id}>{n.label}</option>
                      ))
                    : edges.map((e) => (
                        <option key={e.id} value={e.id}>
                          {nodeMap.get(e.source)?.label} ↔ {nodeMap.get(e.target)?.label}
                        </option>
                      ))}
                </select>
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">Reason</label>
                <input
                  type="text"
                  value={blockReason}
                  onChange={(e) => setBlockReason(e.target.value)}
                  placeholder="e.g. Fire, gas leak, structural damage"
                  className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-sm text-white focus:border-red-500 focus:outline-none"
                />
              </div>
              <button
                onClick={handleAddBlockage}
                disabled={!blockRefId}
                className="flex items-center gap-2 rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-500 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <Ban className="w-4 h-4" />
                Block {blockKind === 'node' ? 'Location' : 'Path'}
              </button>
            </div>
          </div>

          {/* Active blockages */}
          <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-white">Active Blockages ({blockages.length})</h3>
              {blockages.length > 0 && (
                <button
                  onClick={clearBlockages}
                  className="text-xs text-slate-400 hover:text-red-400 transition-colors"
                >
                  Clear all
                </button>
              )}
            </div>
            {blockages.length === 0 ? (
              <div className="text-center py-8">
                <ShieldCheck className="w-8 h-8 text-green-400 mx-auto mb-2" />
                <p className="text-sm text-slate-400">No blockages. All paths are clear.</p>
              </div>
            ) : (
              <div className="space-y-2">
                {blockages.map((b) => {
                  const label =
                    b.kind === 'node'
                      ? nodeMap.get(b.refId)?.label ?? b.refId
                      : (() => {
                          const e = edges.find((ed) => ed.id === b.refId);
                          if (!e) return b.refId;
                          return `${nodeMap.get(e.source)?.label} ↔ ${nodeMap.get(e.target)?.label}`;
                        })();
                  return (
                    <div
                      key={b.id}
                      className="flex items-center gap-3 rounded-lg bg-red-500/10 border border-red-500/20 px-3 py-2.5"
                    >
                      <Ban className="w-4 h-4 text-red-400 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-red-200 truncate">{label}</p>
                        <p className="text-[11px] text-slate-500">{b.reason}</p>
                      </div>
                      <button
                        onClick={() => removeBlockage(b.id)}
                        className="text-slate-500 hover:text-green-400 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
