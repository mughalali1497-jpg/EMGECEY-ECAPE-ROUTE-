// ============================================================================
// HomePage — Landing page with project intro, demo scenario, and quick access
// ----------------------------------------------------------------------------

import {
  Siren,
  Route,
  Map,
  Zap,
  ShieldAlert,
  ArrowRight,
  Info,
  CheckCircle2,
} from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { DEMO_SCENARIO, NODE_MAP } from '@/lib/campusData';
import type { PageId } from '@/components/Sidebar';

interface HomePageProps {
  onNavigate: (page: PageId) => void;
}

export default function HomePage({ onNavigate }: HomePageProps) {
  const { setStartNodeId, setTargetNodeId, addBlockage, clearBlockages } = useApp();

  const loadDemo = () => {
    clearBlockages();
    setStartNodeId(DEMO_SCENARIO.startNodeId);
    for (const edgeId of DEMO_SCENARIO.blockedEdgeIds) {
      addBlockage({ kind: 'edge', refId: edgeId, reason: 'Fire in main corridor' });
    }
    for (const nodeId of DEMO_SCENARIO.blockedNodeIds) {
      addBlockage({ kind: 'node', refId: nodeId, reason: 'Fire in main corridor' });
    }
    onNavigate('planner');
  };

  const startLabel = NODE_MAP.get(DEMO_SCENARIO.startNodeId)?.label ?? 'CS Department';

  return (
    <div className="space-y-6">
      {/* Hero / emergency alert */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900 via-slate-800 to-red-950/40 border border-slate-700 p-8 md:p-10">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute -top-24 -right-24 w-72 h-72 rounded-full bg-red-500 blur-3xl" />
          <div className="absolute -bottom-24 -left-24 w-72 h-72 rounded-full bg-orange-500 blur-3xl" />
        </div>
        <div className="relative">
          <div className="flex items-center gap-2 mb-4">
            <span className="flex items-center gap-1.5 rounded-full bg-red-500/20 border border-red-500/30 px-3 py-1 text-xs font-semibold text-red-300">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              ACADEMIC PROJECT — PROTOTYPE
            </span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-3">
            Emergency Escape Route Planner
          </h1>
          <p className="text-slate-300 text-base md:text-lg max-w-2xl mb-6">
            A Dijkstra-based evacuation system that calculates the shortest safe
            route from your location to the nearest exit during campus emergencies.
          </p>
          <div className="flex flex-wrap gap-3">
            <button
              onClick={loadDemo}
              className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-red-500 to-orange-500 px-6 py-3 text-white font-semibold shadow-lg shadow-red-500/25 hover:shadow-red-500/40 hover:scale-[1.02] transition-all"
            >
              <Siren className="w-5 h-5" />
              Run Demo Scenario
            </button>
            <button
              onClick={() => onNavigate('planner')}
              className="flex items-center gap-2 rounded-xl bg-slate-800 border border-slate-700 px-6 py-3 text-white font-semibold hover:bg-slate-700 transition-colors"
            >
              <Route className="w-5 h-5" />
              Find Escape Route
            </button>
            <button
              onClick={() => onNavigate('map')}
              className="flex items-center gap-2 rounded-xl bg-slate-800 border border-slate-700 px-6 py-3 text-white font-semibold hover:bg-slate-700 transition-colors"
            >
              <Map className="w-5 h-5" />
              View Campus Map
            </button>
          </div>
        </div>
      </div>

      {/* How it works */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { icon: Map, title: '1. Select Location', desc: 'Pick where you are on the campus map.', color: 'text-sky-400' },
          { icon: Zap, title: '2. Graph Analysis', desc: 'Campus is modelled as a weighted graph.', color: 'text-amber-400' },
          { icon: Route, title: "3. Dijkstra's Algorithm", desc: 'Shortest safe path is computed instantly.', color: 'text-green-400' },
          { icon: ShieldAlert, title: '4. Reach Exit', desc: 'Follow the highlighted route to safety.', color: 'text-red-400' },
        ].map((step) => {
          const Icon = step.icon;
          return (
            <div
              key={step.title}
              className="rounded-xl bg-slate-800/50 border border-slate-700 p-5 hover:border-slate-600 transition-colors"
            >
              <Icon className={`w-8 h-8 mb-3 ${step.color}`} />
              <h3 className="text-sm font-semibold text-white mb-1">{step.title}</h3>
              <p className="text-xs text-slate-400 leading-relaxed">{step.desc}</p>
            </div>
          );
        })}
      </div>

      {/* Demo scenario card */}
      <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-6">
        <div className="flex items-start gap-4 mb-4">
          <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-red-500/20 border border-red-500/30 shrink-0">
            <Siren className="w-6 h-6 text-red-400" />
          </div>
          <div className="flex-1">
            <h2 className="text-lg font-bold text-white mb-1">Example Scenario</h2>
            <p className="text-sm text-slate-400">{DEMO_SCENARIO.description}</p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
          <div className="rounded-lg bg-slate-900/60 border border-slate-700 p-4">
            <p className="text-xs text-slate-500 mb-1">Starting Location</p>
            <p className="text-sm font-semibold text-sky-300">{startLabel}</p>
          </div>
          <div className="rounded-lg bg-slate-900/60 border border-slate-700 p-4">
            <p className="text-xs text-slate-500 mb-1">Emergency</p>
            <p className="text-sm font-semibold text-red-300">{DEMO_SCENARIO.emergency}</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2 mb-4">
          {DEMO_SCENARIO.blockedNodeIds.map((id) => (
            <span
              key={id}
              className="flex items-center gap-1.5 rounded-lg bg-red-500/10 border border-red-500/20 px-3 py-1.5 text-xs text-red-300"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              Blocked: {NODE_MAP.get(id)?.label ?? id}
            </span>
          ))}
        </div>
        <button
          onClick={loadDemo}
          className="flex items-center gap-2 text-sm font-semibold text-red-400 hover:text-red-300 transition-colors"
        >
          Load this scenario & plan route
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Features + disclaimer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 rounded-2xl bg-slate-800/50 border border-slate-700 p-6">
          <h2 className="text-lg font-bold text-white mb-4">System Features</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {[
              'Dijkstra\u2019s shortest-path algorithm',
              'Interactive campus map with SVG',
              'Blocked / dangerous path marking',
              'Automatic nearest-exit detection',
              'Alternative route calculation',
              'Step-by-step evacuation directions',
              'Emergency equipment markers',
              'Admin panel for campus management',
              'Distance & time estimates',
              'Dynamic route recalculation',
              'Responsive mobile-friendly design',
              'Demo scenario for viva presentation',
            ].map((feat) => (
              <div key={feat} className="flex items-center gap-2 text-sm text-slate-300">
                <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0" />
                {feat}
              </div>
            ))}
          </div>
        </div>
        <div className="rounded-2xl bg-amber-500/10 border border-amber-500/20 p-6">
          <div className="flex items-center gap-2 mb-3">
            <Info className="w-5 h-5 text-amber-400" />
            <h2 className="text-sm font-bold text-amber-300">Disclaimer</h2>
          </div>
          <p className="text-xs text-amber-200/80 leading-relaxed">
            This is an academic B.Tech CSE project prototype built to demonstrate
            Dijkstra\u2019s algorithm in a real-world scenario. It is not a
            certified emergency safety system and should not be relied upon in
            actual emergencies.
          </p>
          <div className="mt-4 pt-4 border-t border-amber-500/20">
            <p className="text-xs text-slate-400 mb-2">Technology</p>
            <div className="flex flex-wrap gap-1.5">
              {['React', 'TypeScript', 'Dijkstra', 'SVG', 'Tailwind'].map((t) => (
                <span key={t} className="rounded bg-slate-800 px-2 py-0.5 text-[11px] text-slate-300">
                  {t}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
