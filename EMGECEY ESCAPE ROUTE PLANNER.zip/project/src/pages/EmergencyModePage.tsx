// ============================================================================
// EmergencyModePage — Simplified, high-contrast emergency interface
// ----------------------------------------------------------------------------
// This page strips away all non-essential UI and focuses on getting the user
// to safety. It auto-computes the nearest exit and shows large, clear
// instructions. Designed to be readable under stress.
// ============================================================================

import { useMemo, useState, useEffect } from 'react';
import {
  Siren,
  MapPin,
  Flag,
  Clock,
  Ruler,
  AlertTriangle,
  Ban,
  Footprints,
  ListOrdered,
  Volume2,
} from 'lucide-react';
import CampusMap from '@/components/CampusMap';
import { useApp } from '@/context/AppContext';
import { DEMO_SCENARIO, NODE_MAP } from '@/lib/campusData';
import type { PageId } from '@/components/Sidebar';

interface EmergencyModePageProps {
  onNavigate: (page: PageId) => void;
}

function formatTime(seconds: number) {
  if (seconds < 60) return `${seconds}s`;
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}m ${s}s`;
}

export default function EmergencyModePage({ onNavigate }: EmergencyModePageProps) {
  const {
    nodes,
    nodeMap,
    startNodeId,
    setStartNodeId,
    blockages,
    computeNearestExit,
    addBlockage,
    clearBlockages,
  } = useApp();

  const [autoLoaded, setAutoLoaded] = useState(false);

  // Auto-load demo scenario if nothing is set
  useEffect(() => {
    if (!autoLoaded && !startNodeId && blockages.length === 0) {
      setStartNodeId(DEMO_SCENARIO.startNodeId);
      for (const edgeId of DEMO_SCENARIO.blockedEdgeIds) {
        addBlockage({ kind: 'edge', refId: edgeId, reason: 'Fire in main corridor' });
      }
      for (const nodeId of DEMO_SCENARIO.blockedNodeIds) {
        addBlockage({ kind: 'node', refId: nodeId, reason: 'Fire in main corridor' });
      }
      setAutoLoaded(true);
    }
  }, [autoLoaded, startNodeId, blockages.length, setStartNodeId, addBlockage]);

  const nearest = useMemo(() => computeNearestExit(), [computeNearestExit]);

  const routePath = useMemo(
    () => (nearest ? new Set(nearest.route.path) : new Set<string>()),
    [nearest],
  );

  const routeEdgeKeys = useMemo(() => {
    if (!nearest) return new Set<string>();
    const keys = new Set<string>();
    for (let i = 0; i < nearest.route.path.length - 1; i++) {
      keys.add([nearest.route.path[i], nearest.route.path[i + 1]].sort().join('|'));
    }
    return keys;
  }, [nearest]);

  return (
    <div className="space-y-4">
      {/* Emergency banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-red-600 to-orange-600 p-5">
        <div className="absolute inset-0 opacity-20">
          <div className="animate-pulse absolute inset-0 bg-red-400" />
        </div>
        <div className="relative flex items-center gap-4">
          <div className="flex items-center justify-center w-14 h-14 rounded-xl bg-white/20 backdrop-blur-sm">
            <Siren className="w-8 h-8 text-white animate-pulse" />
          </div>
          <div className="flex-1">
            <h1 className="text-2xl font-black text-white tracking-wide">EMERGENCY MODE</h1>
            <p className="text-white/80 text-sm">Follow the highlighted route to the nearest safe exit</p>
          </div>
          <button
            onClick={() => onNavigate('planner')}
            className="rounded-lg bg-white/20 backdrop-blur-sm px-4 py-2 text-sm font-semibold text-white hover:bg-white/30 transition-colors"
          >
            Full Planner →
          </button>
        </div>
      </div>

      {/* Location selector + quick status */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-3">
        <div className="lg:col-span-2 rounded-xl bg-slate-800/50 border border-slate-700 p-4">
          <label className="text-xs text-slate-500 mb-1.5 block flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-sky-400" />
            Your Current Location
          </label>
          <select
            value={startNodeId ?? ''}
            onChange={(e) => setStartNodeId(e.target.value || null)}
            className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2.5 text-base text-white font-semibold focus:border-red-500 focus:outline-none"
          >
            <option value="">— Select your location —</option>
            {nodes.map((n) => (
              <option key={n.id} value={n.id}>{n.label}</option>
            ))}
          </select>
        </div>
        <div className="rounded-xl bg-slate-800/50 border border-slate-700 p-4 flex items-center gap-3">
          <Flag className="w-5 h-5 text-green-400" />
          <div>
            <p className="text-[11px] text-slate-500">Recommended Exit</p>
            <p className="text-sm font-bold text-green-300">
              {nearest ? nodeMap.get(nearest.targetId)?.label : '—'}
            </p>
          </div>
        </div>
        <div className="rounded-xl bg-slate-800/50 border border-slate-700 p-4 flex items-center gap-3">
          <Clock className="w-5 h-5 text-amber-400" />
          <div>
            <p className="text-[11px] text-slate-500">Est. Evacuation Time</p>
            <p className="text-sm font-bold text-amber-300">
              {nearest ? formatTime(nearest.route.timeSeconds) : '—'}
            </p>
          </div>
        </div>
      </div>

      {/* Route summary or no route */}
      {nearest ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Map */}
          <div className="lg:col-span-2">
            <CampusMap routePath={routePath} routeEdgeKeys={routeEdgeKeys} compact />
          </div>

          {/* Instructions panel */}
          <div className="space-y-3">
            {/* Stats */}
            <div className="grid grid-cols-3 gap-2">
              <div className="rounded-xl bg-green-500/10 border border-green-500/30 p-3 text-center">
                <Ruler className="w-4 h-4 text-green-400 mx-auto mb-1" />
                <p className="text-lg font-bold text-white">{nearest.route.distance}m</p>
                <p className="text-[10px] text-slate-500">Distance</p>
              </div>
              <div className="rounded-xl bg-amber-500/10 border border-amber-500/30 p-3 text-center">
                <Clock className="w-4 h-4 text-amber-400 mx-auto mb-1" />
                <p className="text-lg font-bold text-white">{formatTime(nearest.route.timeSeconds)}</p>
                <p className="text-[10px] text-slate-500">Time</p>
              </div>
              <div className="rounded-xl bg-sky-500/10 border border-sky-500/30 p-3 text-center">
                <Footprints className="w-4 h-4 text-sky-400 mx-auto mb-1" />
                <p className="text-lg font-bold text-white">{nearest.route.path.length}</p>
                <p className="text-[10px] text-slate-500">Steps</p>
              </div>
            </div>

            {/* Directions */}
            <div className="rounded-2xl bg-slate-800/50 border border-slate-700 p-4">
              <h3 className="flex items-center gap-2 text-sm font-bold text-white mb-3">
                <ListOrdered className="w-4 h-4 text-green-400" />
                Evacuation Directions
              </h3>
              <ol className="space-y-2.5">
                {nearest.route.directions.map((dir, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm text-slate-200">
                    <span className="flex items-center justify-center w-7 h-7 rounded-full bg-green-500/20 text-green-300 text-xs font-bold shrink-0">
                      {i + 1}
                    </span>
                    <span className="leading-relaxed pt-0.5">{dir}</span>
                  </li>
                ))}
              </ol>
            </div>

            {/* Safety instructions */}
            <div className="rounded-2xl bg-red-500/10 border border-red-500/30 p-4">
              <h3 className="flex items-center gap-2 text-sm font-bold text-red-300 mb-2">
                <AlertTriangle className="w-4 h-4" />
                Safety Instructions
              </h3>
              <ul className="space-y-1.5 text-xs text-slate-300">
                <li>• Stay calm and walk quickly — do not run.</li>
                <li>• Follow the green highlighted path on the map.</li>
                <li>• Avoid areas marked with red hazard indicators.</li>
                <li>• Do not use elevators — use stairs only.</li>
                <li>• Help others who need assistance if possible.</li>
                <li>• Once outside, move away from the building.</li>
                <li>• Call emergency services if you haven\u2019t already.</li>
              </ul>
            </div>
          </div>
        </div>
      ) : (
        <div className="rounded-2xl bg-red-500/10 border border-red-500/30 p-8 text-center">
          <AlertTriangle className="w-12 h-12 text-red-400 mx-auto mb-4 animate-pulse" />
          <h2 className="text-xl font-bold text-white mb-2">No Safe Exit Found</h2>
          <p className="text-sm text-slate-400 max-w-md mx-auto mb-4">
            {startNodeId
              ? 'All exit routes from your location are currently blocked. Seek shelter and call emergency services.'
              : 'Please select your current location to begin evacuation routing.'}
          </p>
          {!startNodeId && (
            <div className="max-w-xs mx-auto">
              <select
                value={startNodeId ?? ''}
                onChange={(e) => setStartNodeId(e.target.value || null)}
                className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2.5 text-sm text-white"
              >
                <option value="">— Select your location —</option>
                {nodes.map((n) => (
                  <option key={n.id} value={n.id}>{n.label}</option>
                ))}
              </select>
            </div>
          )}
        </div>
      )}

      {/* Blockage warnings */}
      {blockages.length > 0 && (
        <div className="rounded-2xl bg-red-500/10 border border-red-500/20 p-4">
          <h3 className="flex items-center gap-2 text-sm font-bold text-red-300 mb-3">
            <Ban className="w-4 h-4" />
            Blocked Areas — AVOID ({blockages.length})
          </h3>
          <div className="flex flex-wrap gap-2">
            {blockages.map((b) => {
              const label =
                b.kind === 'node'
                  ? nodeMap.get(b.refId)?.label ?? b.refId
                  : `Path ${b.refId}`;
              return (
                <span
                  key={b.id}
                  className="flex items-center gap-1.5 rounded-lg bg-red-500/15 border border-red-500/30 px-3 py-1.5 text-xs text-red-200 font-medium"
                >
                  <Ban className="w-3 h-3" />
                  {label}
                </span>
              );
            })}
          </div>
        </div>
      )}

      {/* Reset demo */}
      <div className="flex items-center justify-between rounded-xl bg-slate-800/50 border border-slate-700 px-4 py-3">
        <span className="flex items-center gap-2 text-xs text-slate-400">
          <Volume2 className="w-4 h-4" />
          Demo scenario auto-loaded: {DEMO_SCENARIO.emergency}
        </span>
        <button
          onClick={() => {
            clearBlockages();
            setAutoLoaded(false);
          }}
          className="rounded-lg bg-slate-700 px-3 py-1.5 text-xs font-semibold text-slate-300 hover:bg-slate-600 transition-colors"
        >
          Reset
        </button>
      </div>
    </div>
  );
}
