import { useState } from 'react';
import { Menu, X, Siren } from 'lucide-react';
import { AppProvider } from '@/context/AppContext';
import { EmergencyProvider } from '@/context/EmergencyContext';
import { VoiceProvider } from '@/context/VoiceContext';
import Sidebar, { type PageId } from '@/components/Sidebar';
import GuidanceDrop from '@/components/GuidanceDrop';
import HomePage from '@/pages/HomePage';
import CampusMapPage from '@/pages/CampusMapPage';
import RoutePlannerPage from '@/pages/RoutePlannerPage';
import EmergencyModePage from '@/pages/EmergencyModePage';
import StudentPanelPage from '@/pages/StudentPanelPage';
import AdminPanelPage from '@/pages/AdminPanelPage';

function App() {
  const [page, setPage] = useState<PageId>('home');
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const navigate = (p: PageId) => {
    setPage(p);
    setMobileNavOpen(false);
  };

  return (
    <AppProvider>
      <EmergencyProvider>
      <VoiceProvider>
      <div className="min-h-screen bg-slate-950 text-white flex">
        {/* Desktop sidebar */}
        <aside className="hidden lg:flex w-64 shrink-0 bg-slate-900 border-r border-slate-800 flex-col sticky top-0 h-screen">
          <Sidebar current={page} onNavigate={navigate} />
        </aside>

        {/* Mobile sidebar overlay */}
        {mobileNavOpen && (
          <div className="lg:hidden fixed inset-0 z-50 flex">
            <div
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => setMobileNavOpen(false)}
            />
            <aside className="relative w-72 bg-slate-900 border-r border-slate-800 flex flex-col">
              <button
                onClick={() => setMobileNavOpen(false)}
                className="absolute top-3 right-3 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
              <Sidebar current={page} onNavigate={navigate} />
            </aside>
          </div>
        )}

        {/* Main content */}
        <main className="flex-1 min-w-0 flex flex-col">
          {/* Desktop top bar with guidance dropdown */}
          <header className="hidden lg:flex items-center justify-between bg-slate-900 border-b border-slate-800 px-6 py-3 sticky top-0 z-40">
            <div className="flex items-center gap-2.5">
              <Siren className="w-5 h-5 text-red-400" />
              <span className="text-sm font-semibold text-slate-300">
                {page === 'home' && 'Dashboard'}
                {page === 'map' && 'Campus Map'}
                {page === 'planner' && 'Route Planner'}
                {page === 'emergency' && 'Emergency Mode'}
                {page === 'students' && 'Student Panel'}
                {page === 'admin' && 'Admin Panel'}
              </span>
            </div>
            <GuidanceDrop />
          </header>

          {/* Mobile header */}
          <header className="lg:hidden flex items-center justify-between bg-slate-900 border-b border-slate-800 px-4 py-3 sticky top-0 z-40">
            <div className="flex items-center gap-2">
              <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-br from-red-500 to-orange-500">
                <span className="text-white font-bold text-sm">E</span>
              </div>
              <span className="text-sm font-bold">Escape Route Planner</span>
            </div>
            <div className="flex items-center gap-2">
              <GuidanceDrop />
              <button
                onClick={() => setMobileNavOpen(true)}
                className="text-slate-400 hover:text-white"
              >
                <Menu className="w-6 h-6" />
              </button>
            </div>
          </header>

          {/* Page content */}
          <div className="flex-1 p-4 md:p-6 lg:p-8 max-w-7xl mx-auto w-full">
            {page === 'home' && <HomePage onNavigate={navigate} />}
            {page === 'map' && <CampusMapPage onNavigate={navigate} />}
            {page === 'planner' && <RoutePlannerPage onNavigate={navigate} />}
            {page === 'emergency' && <EmergencyModePage onNavigate={navigate} />}
            {page === 'students' && <StudentPanelPage onNavigate={navigate} />}
            {page === 'admin' && <AdminPanelPage />}
          </div>
        </main>
      </div>
      </VoiceProvider>
      </EmergencyProvider>
    </AppProvider>
  );
}

export default App;
