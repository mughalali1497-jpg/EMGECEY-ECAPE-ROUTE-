/*
# Create problem_reports table and storage bucket for report photos

1. Purpose
   - Students can report campus safety problems (blocked exits, fire/smoke,
     broken equipment, unsafe areas, etc.) with photo uploads.
   - Admins see all reports in the Admin Panel and can use them to decide
     whether to declare an emergency.

2. New Tables
   - problem_reports
     - id (uuid, primary key)
     - student_name (text, not null) — reporter's name
     - student_roll_number (text) — roll number
     - student_mobile (text) — mobile number
     - problem_type (text, not null) — e.g. "Blocked Emergency Exit"
     - building_block (text) — building or block name
     - floor (text) — floor number/level
     - room_area (text) — room or area description
     - map_node_id (text) — optional reference to a campus map node
     - description (text) — detailed problem description
     - photo_url (text) — URL to uploaded photo in storage bucket
     - priority (text, not null) — "Low" | "Medium" | "High" | "Critical"
     - status (text, not null) — "pending" | "reviewed" | "resolved"
     - admin_notes (text) — admin response notes
     - created_at (timestamptz)
     - updated_at (timestamptz)

3. Storage
   - Create a public bucket "report-photos" for student-uploaded photos.
   - Allow public read + anon upload.

4. Security
   - No-auth single-tenant app: policies use TO anon, authenticated.
   - RLS enabled on problem_reports with full CRUD for anon + authenticated.
   - Storage bucket is public for read and write (student uploads).

5. Notes
   - updated_at auto-updated via trigger (reuse existing set_updated_at function).
*/

CREATE TABLE IF NOT EXISTS problem_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_name text NOT NULL,
  student_roll_number text DEFAULT '',
  student_mobile text DEFAULT '',
  problem_type text NOT NULL,
  building_block text DEFAULT '',
  floor text DEFAULT '',
  room_area text DEFAULT '',
  map_node_id text DEFAULT '',
  description text DEFAULT '',
  photo_url text DEFAULT '',
  priority text NOT NULL DEFAULT 'Medium',
  status text NOT NULL DEFAULT 'pending',
  admin_notes text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE problem_reports ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "pr_select_all" ON problem_reports;
CREATE POLICY "pr_select_all" ON problem_reports FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "pr_insert_all" ON problem_reports;
CREATE POLICY "pr_insert_all" ON problem_reports FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "pr_update_all" ON problem_reports;
CREATE POLICY "pr_update_all" ON problem_reports FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "pr_delete_all" ON problem_reports;
CREATE POLICY "pr_delete_all" ON problem_reports FOR DELETE
  TO anon, authenticated USING (true);

-- updated_at trigger (reuse existing function)
DROP TRIGGER IF EXISTS trg_problem_reports_updated ON problem_reports;
CREATE TRIGGER trg_problem_reports_updated
  BEFORE UPDATE ON problem_reports
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Create storage bucket for report photos
INSERT INTO storage.buckets (id, name, public)
VALUES ('report-photos', 'report-photos', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies: allow anon read + upload
DROP POLICY IF EXISTS "report_photos_read" ON storage.objects;
CREATE POLICY "report_photos_read" ON storage.objects
  FOR SELECT TO anon, authenticated
  USING (bucket_id = 'report-photos');

DROP POLICY IF EXISTS "report_photos_insert" ON storage.objects;
CREATE POLICY "report_photos_insert" ON storage.objects
  FOR INSERT TO anon, authenticated
  WITH CHECK (bucket_id = 'report-photos');

DROP POLICY IF EXISTS "report_photos_delete" ON storage.objects;
CREATE POLICY "report_photos_delete" ON storage.objects
  FOR DELETE TO anon, authenticated
  USING (bucket_id = 'report-photos');
