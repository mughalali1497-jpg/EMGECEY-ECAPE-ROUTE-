/*
# Add optional voice_message column to emergency_state

1. Purpose
   - Adds an optional `voice_message` text column to the `emergency_state` table.
   - This lets the admin type a custom message in their own words that will be
     spoken aloud (via the browser's SpeechSynthesis API) in addition to the
     predefined emergency announcement.
   - The column is nullable / defaults to empty string so existing rows and
     activations that don't provide a custom message are unaffected.

2. Modified Tables
   - emergency_state:
     - New column: voice_message (text, default '') — optional admin-authored
       message appended to the predefined voice announcement.

3. Security
   - No changes to RLS policies. The existing emergency_state policies already
     allow anon + authenticated full CRUD, so the new column is accessible
     under the same rules.
*/

ALTER TABLE emergency_state
  ADD COLUMN IF NOT EXISTS voice_message text DEFAULT '';
