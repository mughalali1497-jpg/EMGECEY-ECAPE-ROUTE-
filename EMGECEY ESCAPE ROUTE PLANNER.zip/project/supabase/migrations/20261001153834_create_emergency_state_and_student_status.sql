/*
# Create emergency_state and student_status tables

1. Purpose
   - `emergency_state` is a single-row table that the admin toggles to declare
     an active emergency. When active, the student panel unlocks and students
     can mark themselves safe or in-danger and see the campus map.
   - `student_status` stores per-student safety check-ins during an active
     emergency (name, location, status, notes, timestamp).

2. New Tables

   a) emergency_state
      - id (int, primary key, always 1) — enforced single-row via DEFAULT 1
      - is_active (boolean, default false) — whether an emergency is declared
      - emergency_type (text) — e.g. "Fire", "Earthquake", "Gas Leak"
      - description (text) — admin-provided details of the emergency
      - activated_at (timestamptz) — when the emergency was declared
      - updated_at (timestamptz) — last change timestamp

   b) student_status
      - id (uuid, primary key)
      - student_name (text, not null) — student's display name
      - student_id_number (text) — roll number / student ID
      - location (text) — where the student currently is on campus
      - status (text, not null) — "safe" | "in_danger" | "evacuating"
      - notes (text) — optional message from the student
      - emergency_id (int) — references emergency_state(id), links to the active emergency
      - created_at (timestamptz) — when the check-in was submitted
      - updated_at (timestamptz) — last update timestamp

3. Security
   - This is a no-auth single-tenant app (no sign-in screen). All policies use
     TO anon, authenticated so the anon-key frontend can read/write.
   - RLS enabled on both tables.
   - Full CRUD allowed for anon + authenticated on both tables — data is
     intentionally shared (admin sees all student statuses, students see the
     emergency state and submit their own status).

4. Notes
   - emergency_state is seeded with a single row (id=1, is_active=false) so the
     frontend can read it immediately.
   - A trigger auto-updates updated_at on every row change.
*/

-- ---------- emergency_state ----------
CREATE TABLE IF NOT EXISTS emergency_state (
  id int PRIMARY KEY DEFAULT 1,
  is_active boolean NOT NULL DEFAULT false,
  emergency_type text DEFAULT '',
  description text DEFAULT '',
  activated_at timestamptz,
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT single_row CHECK (id = 1)
);

ALTER TABLE emergency_state ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "es_select_all" ON emergency_state;
CREATE POLICY "es_select_all" ON emergency_state FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "es_insert_all" ON emergency_state;
CREATE POLICY "es_insert_all" ON emergency_state FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "es_update_all" ON emergency_state;
CREATE POLICY "es_update_all" ON emergency_state FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "es_delete_all" ON emergency_state;
CREATE POLICY "es_delete_all" ON emergency_state FOR DELETE
  TO anon, authenticated USING (true);

-- Seed the single row if it doesn't exist
INSERT INTO emergency_state (id, is_active)
VALUES (1, false)
ON CONFLICT (id) DO NOTHING;

-- ---------- student_status ----------
CREATE TABLE IF NOT EXISTS student_status (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_name text NOT NULL,
  student_id_number text DEFAULT '',
  location text DEFAULT '',
  status text NOT NULL DEFAULT 'evacuating',
  notes text DEFAULT '',
  emergency_id int REFERENCES emergency_state(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE student_status ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "ss_select_all" ON student_status;
CREATE POLICY "ss_select_all" ON student_status FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "ss_insert_all" ON student_status;
CREATE POLICY "ss_insert_all" ON student_status FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "ss_update_all" ON student_status;
CREATE POLICY "ss_update_all" ON student_status FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "ss_delete_all" ON student_status;
CREATE POLICY "ss_delete_all" ON student_status FOR DELETE
  TO anon, authenticated USING (true);

-- ---------- updated_at triggers ----------
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_emergency_state_updated ON emergency_state;
CREATE TRIGGER trg_emergency_state_updated
  BEFORE UPDATE ON emergency_state
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

DROP TRIGGER IF EXISTS trg_student_status_updated ON student_status;
CREATE TRIGGER trg_student_status_updated
  BEFORE UPDATE ON student_status
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
